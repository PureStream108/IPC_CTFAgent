"""Register the bundled local skill package so Members can read it.

The bundled upstream package is copied by SkillStore.bootstrap() because its
repository name matches DEFAULT_REPOSITORY. This module installs the package
that ships with the image itself (a local VM-reversing playbook), keyed by a
stable synthetic revision so a restart does not duplicate it.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
from pathlib import Path

REPOSITORY = "ipc/local"
REVISION = "0" * 32 + "1a2b3c4d"          # 40 hex chars: the store validates length
PACKAGE_NAME = "vm-reverse"
SOURCE = Path(os.environ.get("IPC_SKILL_SOURCE") or "/app/hosted/skills")


def main() -> int:
    artifact = Path(os.environ.get("IPC_ARTIFACT_ROOT") or "/app/data/artifacts")
    root = artifact / "skills"
    root.mkdir(parents=True, exist_ok=True)
    source = SOURCE / PACKAGE_NAME
    if not (source / "SKILL.md").is_file():
        print("[skills] no local package at " + str(source), flush=True)
        return 0
    key = hashlib.sha256((REPOSITORY + "@" + REVISION).encode()).hexdigest()
    target = root / key
    if not target.exists():
        shutil.copytree(source, target)
    skills = sorted(str(p.relative_to(target)) for p in target.rglob("SKILL.md"))
    payload = {
        "repository": REPOSITORY,
        "revision": REVISION,
        "skills": skills,
        "archive_sha256": "",
    }
    (target / "manifest.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    state_path = root / "state.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {"packages": {}}
    state.setdefault("packages", {})[REPOSITORY] = {
        "revision": REVISION,
        "enabled": True,
        "directory": key,
    }
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[skills] registered " + REPOSITORY + ": " + ", ".join(skills), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
