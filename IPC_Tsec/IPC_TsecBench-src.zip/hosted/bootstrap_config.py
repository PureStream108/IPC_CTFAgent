"""Render backend/config/config.yaml from the hosted container environment.

The TSecBench hosted sandbox has no public internet. Every model call must go
through the platform gateway, whose rule is: append ".tsecbench.gw" to the
original host and downgrade https to http. The original path is preserved, so
https://api.deepseek.com/anthropic becomes
http://api.deepseek.com.tsecbench.gw/anthropic.

Nothing secret is baked into the image. The runtime environment configured on
the prepare page supplies the API key; this module only turns it into the YAML
that IPC reads at startup.

Run as a script:
    python -m hosted.bootstrap_config
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

# The gateway rule, the model names and the hosted defaults live in the adapter
# package so the image, the autopilot and the tests cannot drift apart.
from backend.platform.tsecbench.defaults import (
    DEFAULT_MODEL,
    GATEWAY_SUFFIX,
    HOSTED_DEFAULTS,
    KNOWN_BASE_URLS,
    PROVIDER_TIMEOUTS,
    SUPPORTED_API_FORMATS,
    default_model as _platform_default_model,
    via_gateway as _platform_via_gateway,
)

DEFAULT_BASE_URL = dict(KNOWN_BASE_URLS)
FORMATS = set(SUPPORTED_API_FORMATS)
SURFACES = {"auto", "chat_completions", "responses"}
EFFORTS = {"auto", "none", "minimal", "low", "medium", "high", "xhigh", "max"}
DEFAULT_MODELS = {
    "openai": "gpt-5.5",
    "anthropic": "claude-opus-4-8",
    "deepseek": DEFAULT_MODEL,
}


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def flag(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None or not value.strip():
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def via_gateway(url: str) -> str:
    """Rewrite one model base URL to the hosted gateway form."""

    return _platform_via_gateway(url, suffix=GATEWAY_SUFFIX)


def default_model(api_format: str, base_url: str) -> str:
    """Ask the platform defaults, then fall back to the generic map."""

    if "deepseek" in (base_url or ""):
        return DEFAULT_MODEL
    return _platform_default_model(api_format, base_url) or DEFAULT_MODELS.get(api_format, "")


def _choice(name: str, value: str, allowed: set, fallback: str) -> str:
    if not value:
        return fallback
    if value not in allowed:
        raise SystemExit(name + "=" + repr(value) + " is not one of " + repr(sorted(allowed)))
    return value


def agent_config(override: str = "") -> dict:
    """Build one LLM block; override is "IPC_DIAMOND_" for a Diamond override."""

    def read(suffix: str, shared: str) -> str:
        if override:
            value = env(override + suffix)
            if value:
                return value
        return env(shared)

    api_format = _choice(
        "IPC_LLM_API_FORMAT",
        read("API_FORMAT", "IPC_LLM_API_FORMAT"),
        FORMATS,
        "anthropic",
    )
    base_url = read("BASE_URL", "IPC_LLM_BASE_URL") or DEFAULT_BASE_URL.get(api_format, "")
    if flag("IPC_LLM_GATEWAY", True):
        base_url = via_gateway(base_url)
    api_surface = _choice("IPC_LLM_API_SURFACE", read("API_SURFACE", "IPC_LLM_API_SURFACE"), SURFACES, "auto")
    effort = _choice("IPC_LLM_REASONING_EFFORT", read("REASONING_EFFORT", "IPC_LLM_REASONING_EFFORT"), EFFORTS, "max")
    key = read("API_KEY", "IPC_LLM_API_KEY") or env("IPC_HOSTED_API_KEY")
    model = read("MODEL", "IPC_LLM_MODEL") or default_model(api_format, base_url)
    return {
        "api_format": api_format,
        "api_surface": api_surface,
        "reasoning_effort": effort,
        "api_key": key,
        "base_url": base_url,
        "model": model,
    }


def _int(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(env(name) or default)
    except ValueError:
        return default
    return max(low, min(high, value))


def build() -> dict:
    return {
        "log_enabled": flag("IPC_LOG_ENABLED", True),
        "diamond": agent_config("IPC_DIAMOND_"),
        "member": agent_config(),
        "member_config_conflict": False,
        "members": [],
        "runtime": {
            # The hosted container is already a disposable sandbox, so Members
            # run in it directly: no docker daemon exists inside the platform
            # image and none can be nested.
            "sandbox_backend": "local",
            "per_challenge_minutes": _int(
                "IPC_HOSTED_PER_CHALLENGE_MINUTES",
                HOSTED_DEFAULTS["per_challenge_minutes"], 10, 1440,
            ),
            "max_member_steps": _int("IPC_HOSTED_MEMBER_STEPS", 60, 1, 100000),
            "max_member_actions_per_task": _int("IPC_HOSTED_MEMBER_ACTIONS", 20, 1, 100000),
            "diamond_pentest_mode": False,
            "diamond_actions_per_tick": 2,
            "state_write_ratio": 0.85,
            # A stalled gateway response must fail fast. The defaults (300 s
            # read, 900 s turn) let six Members sit on a dead connection for a
            # quarter of the benchmark window without producing a single log
            # line or model call.
            "provider_read_timeout": _int(
                "IPC_HOSTED_PROVIDER_READ_TIMEOUT", PROVIDER_TIMEOUTS["read"], 30, 3600,
            ),
            "provider_turn_timeout": _int(
                "IPC_HOSTED_PROVIDER_TURN_TIMEOUT", PROVIDER_TIMEOUTS["turn"], 30, 7200,
            ),
            "provider_progress_timeout": _int(
                "IPC_HOSTED_PROVIDER_PROGRESS_TIMEOUT", PROVIDER_TIMEOUTS["progress"], 10, 3600,
            ),
        },
        "limits": {
            "total_cpu": _int("IPC_HOSTED_CPUS", 8, 1, 128),
            "max_concurrent_tasks": _int("IPC_HOSTED_MAX_TASKS", 10, 1, 10),
            "network": True,
        },
    }


def seed_ops_agent(diamond: dict) -> None:
    """Give the IPC conversation agent the same endpoint as Diamond.

    The operator chat is not part of the run, but it is the only way to ask an
    uploaded image what it is doing, and it keeps its own credentials in
    data/ops-agent rather than in config.yaml. Seeding is skipped when the file
    already exists so a restart never overwrites a change made in the UI.
    """

    if not flag("IPC_OPS_SEED", True):
        return
    base_url = env("IPC_OPS_BASE_URL") or diamond["base_url"]
    api_key = env("IPC_OPS_API_KEY") or env("IPC_DIAMOND_API_KEY") or diamond["api_key"]
    if not api_key or not base_url:
        return
    directory = Path(os.environ.get("IPC_ROOT") or "/app") / "data" / "ops-agent"
    config_path = directory / "config.json"
    if config_path.exists():
        print("[config] ops-agent already configured at " + str(config_path), flush=True)
        return
    directory.mkdir(parents=True, exist_ok=True)
    try:
        directory.chmod(0o700)
    except OSError:
        pass
    model = env("IPC_OPS_MODEL") or diamond["model"]
    config_path.write_text(
        json.dumps(
            {
                "api_format": _choice("IPC_OPS_API_FORMAT", env("IPC_OPS_API_FORMAT"), FORMATS, diamond["api_format"]),
                "api_surface": _choice("IPC_OPS_API_SURFACE", env("IPC_OPS_API_SURFACE"), SURFACES, diamond["api_surface"]),
                "reasoning_effort": _choice(
                    "IPC_OPS_REASONING_EFFORT", env("IPC_OPS_REASONING_EFFORT"), EFFORTS, diamond["reasoning_effort"]
                ),
                "base_url": base_url,
                "model": model,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    (directory / "secrets.json").write_text(
        json.dumps({"llm_api_key": api_key, "sessions": {}, "workflows": {}}, indent=2),
        encoding="utf-8",
    )
    print("[config] seeded the IPC conversation agent: " + model + " at " + base_url, flush=True)


def main() -> int:
    import yaml

    config_dir = Path(os.environ.get("IPC_CONFIG_DIR") or Path("backend/config").resolve())
    config_dir.mkdir(parents=True, exist_ok=True)
    target = config_dir / "config.yaml"
    data = build()
    target.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
    printable = {k: v for k, v in data["member"].items() if k != "api_key"}
    printable["api_key_set"] = bool(data["member"]["api_key"])
    print("[config] wrote " + str(target), flush=True)
    print("[config] member " + repr(printable), flush=True)
    print(
        "[config] diamond " + repr({k: v for k, v in data["diamond"].items() if k != "api_key"})
        + " api_key_set=" + str(bool(data["diamond"]["api_key"])),
        flush=True,
    )
    seed_ops_agent(data["diamond"])

    try:
        from backend.core.config import load_config
    except Exception as exc:  # noqa: BLE001 - the caller needs the message
        print("[config] cannot import backend: " + str(exc), file=sys.stderr, flush=True)
        return 1
    cfg = load_config(config_dir)
    errors = cfg.startup_errors()
    if errors:
        for error in errors:
            print("[config] STARTUP ERROR: " + error, file=sys.stderr, flush=True)
        return 1
    for warning in cfg.startup_warnings():
        print("[config] warning: " + warning, flush=True)
    print("[config] ready with members " + repr([m.name for m in cfg.available_members()]), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
