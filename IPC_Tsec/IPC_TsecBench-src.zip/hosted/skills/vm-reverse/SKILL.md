# Reversing a bytecode interpreter inside a native binary

This is a method, not a recipe for one target. It applies to any binary that
ships its own instruction set: the check logic lives in data, and the code is a
loop that fetches, decodes and executes that data.

## 1. Establish what kind of program it is

```
file bin; readelf -hW bin | head -20; readelf -SW bin | grep -E 'text|rodata|data|bss'
strings -a -n 4 bin | head -80
r2 -q -c 'aaa; afl' bin | head -40
```

Signals of an interpreter: one large function with a `switch` or a jump table,
a data section whose bytes do not decode as text, and a loop that keeps reading
from a single base pointer. Signals of firmware: non-x86 machine type — run it
with the matching `qemu-<arch>` instead of `gdb` on the host.

## 2. Separate the layers before analysing either

Write down, for the entry function: which register or variable is the program
counter, which is the bytecode base, which is the working state, and where the
input string is read. If those four are not identified, static reading turns
into guessing.

## 3. Trace the loop instead of reading it

A debugger script beats manual stepping: break at the dispatch head and print
the counter, the fetched byte and the operands on every hit.

```
cat > trace.gdb <<'EOF'
set pagination off
set disable-randomization on
break *<dispatch-address-or-main+offset>
commands
silent
printf "pc=%d op=%02x a=%d b=%d\n", $<pc>, *(unsigned char*)($<base>+$<pc>), $<a>, $<b>
continue
end
run <candidate-input>
EOF
gdb -q -batch -x trace.gdb --args ./bin <candidate-input> | tee trace.txt
```

Replace the `<...>` tokens with the registers found in step 2. On a PIE binary
add the load base from `info proc mappings` or break on `main+<offset>`.

## 4. Build the opcode table from the trace

Group `trace.txt` by `op` and diff the effect of each group. A small VM has ten
to twenty opcodes: load immediate, arithmetic, compare, conditional branch,
load/store, call, output. Only after that table exists is the program readable.

## 5. Recover data that is encoded

Compare the bytes on disk with the bytes the loop actually consumes
(`x/64xb <base>` at the dispatch). Any difference is the decoding step. Verify a
candidate key by re-encoding the observed memory and matching the file; do not
settle for a key that merely looks plausible in a register.

## 6. Execute rather than fully understand

- `unicorn` plus `capstone`: map the bytecode page, implement one handler per
  opcode, run it. This is the reliable route when the table is partly unknown.
- Patching: neutralise the compare/branch, or set the program counter past the
  check in the debugger, then let the original binary produce its output.
- `z3` only when the final check is plain arithmetic over the input bytes.
- For ARM/MIPS firmware use `qemu-<arch>`; the host debugger cannot execute it.

## 7. Sanity rules

- A run that exits cleanly without printing anything is a rejected path, not a
  success. Compare the exit status and the output length of a known-bad input.
- Keep the disassembly, the trace and the opcode table in the workspace, so a
  fresh container can continue instead of restarting the analysis.
- Report the table and the last confirmed fact when the attempt ends; the next
  seat reads that report before touching the binary again.
