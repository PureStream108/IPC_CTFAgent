"""Start and supervise one TSecBench evaluation with no human in the loop.

The hosted sandbox runs this image and nothing else: no browser, no operator,
no shell. So the whole operator sequence that the prepare page documents is
replayed here against the local IPC API:

    1. wait until IPC answers /health
    2. create (or reuse) the TSecBench workflow from BENCHMARK_BASE_URL and
       BENCHMARK_TOKEN, which the platform injects into the container
    3. confirm the workflow, which is what authorizes its HTTP capability
    4. preflight: read the challenge list from the platform
    5. start the run: the scheduler pulls containers and assigns Members
    6. supervise until the run reaches a terminal state

Every step is idempotent, so a restarted container resumes instead of
duplicating work: the workflow is matched by base URL and the run by a
deterministic idempotency key derived from the task token.

Run as a script:
    python -m hosted.autopilot
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request

from backend.platform.tsecbench.defaults import HOSTED_DEFAULTS
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

API_BASE = (os.environ.get("IPC_API_URL") or "http://127.0.0.1:8000").rstrip("/")
STATE_DIR = Path(os.environ.get("IPC_HOSTED_STATE_DIR") or "/app/data/hosted")
TERMINAL = {"finished", "stopped", "failed"}
SOLVED = {"solved", "external_solved"}
POLL_SECONDS = float(os.environ.get("IPC_HOSTED_POLL_SECONDS") or 30)
# A six-hour run that only logs on change looks dead in the platform's audit
# trail, so the summary is repeated on a fixed cadence as well.
HEARTBEAT_SECONDS = float(os.environ.get("IPC_HOSTED_HEARTBEAT_SECONDS") or 300)
HEALTH_TIMEOUT = float(os.environ.get("IPC_HOSTED_HEALTH_TIMEOUT") or 600)


class ApiError(RuntimeError):
    def __init__(self, status: int, detail: str) -> None:
        super().__init__("HTTP " + str(status) + ": " + detail[:400])
        self.status = status
        self.detail = detail

    @property
    def permanent(self) -> bool:
        return self.status in {400, 401, 403, 404, 422}


def log(message: str) -> None:
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print("[autopilot] " + stamp + " " + message, flush=True)


def request(method: str, path: str, payload=None, timeout: float = 120.0):
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(API_BASE + path, data=body, method=method)
    if body is not None:
        req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        raise ApiError(exc.code, exc.read().decode("utf-8", "replace")) from exc
    except urllib.error.URLError as exc:
        raise ApiError(0, "connection failed: " + str(exc.reason)) from exc
    return json.loads(raw.decode("utf-8")) if raw else None


def retry(call, what: str, attempts: int = 5, delay: float = 5.0):
    for attempt in range(1, attempts + 1):
        try:
            return call()
        except ApiError as exc:
            if exc.permanent or attempt == attempts:
                raise
            log(what + " failed (" + str(exc) + "); retry " + str(attempt) + "/" + str(attempts))
            time.sleep(delay * attempt)
    raise RuntimeError("unreachable")


def wait_for_server() -> None:
    deadline = time.time() + HEALTH_TIMEOUT
    while time.time() < deadline:
        try:
            request("GET", "/health", timeout=10)
            log("IPC server is up at " + API_BASE)
            return
        except ApiError:
            time.sleep(3)
    raise SystemExit("IPC server did not answer /health within " + str(int(HEALTH_TIMEOUT)) + "s")


def workflow_idempotency_token() -> str:
    token = os.environ.get("BENCHMARK_TOKEN", "")
    base = os.environ.get("BENCHMARK_BASE_URL", "")
    return hashlib.sha256((base + "|" + token).encode("utf-8")).hexdigest()[:24]


def workflow_payload(base_url: str, token: str) -> dict:
    payload = {
        "base_url": base_url,
        "name": "TSecBench hosted",
        "remote_concurrency": int(
            os.environ.get("IPC_HOSTED_REMOTE_CONCURRENCY")
            or HOSTED_DEFAULTS["remote_concurrency"]
        ),
        "duration_minutes": int(
            os.environ.get("IPC_HOSTED_DURATION_MINUTES") or HOSTED_DEFAULTS["duration_minutes"]
        ),
        "secrets": {"benchmark_token": token},
    }
    if flag_truthy_default("IPC_HOSTED_ALLOW_HINTS", HOSTED_DEFAULTS["allow_hints"]):
        # A parked challenge that already burned two 45 minute attempts is
        # better served by one score-discounted hint than a third blind try.
        payload["allow_hints"] = True
    if allow_private_networks(base_url):
        payload["allow_private_networks"] = True
    return payload


def ensure_workflow(base_url: str, token: str) -> str:
    payload = workflow_payload(base_url, token)
    workflows = retry(lambda: request("GET", "/api/ops/workflows"), "list workflows")["workflows"]
    for item in workflows:
        spec = item.get("spec") or {}
        challenges = spec.get("challenges") or {}
        if (challenges.get("list_url") or "").rstrip("/") != base_url:
            continue
        workflow_id = item["id"]
        log("reusing workflow " + workflow_id + " status=" + str(item.get("status")))
        retry(
            lambda: request(
                "PUT",
                "/api/ops/workflows/" + workflow_id + "/secrets",
                {"secrets": {"benchmark_token": token}},
            ),
            "set workflow secrets",
        )
        if bool(spec.get("allow_private_networks")) != bool(payload.get("allow_private_networks")):
            # A workflow saved before the gateway shape was recognised keeps
            # its old network policy, and re-confirming it would fail the same
            # way. Rewrite it instead of starting a second workflow.
            log("updating the workflow network policy to match the task origin")
            retry(
                lambda: request("PUT", "/api/ops/workflows/" + workflow_id + "/tsecbench", payload),
                "update workflow",
            )
        return workflow_id

    created = retry(
        lambda: request("POST", "/api/ops/workflows/tsecbench", payload),
        "create workflow",
    )
    workflow_id = created["id"]
    log("created workflow " + workflow_id)
    return workflow_id


def allow_private_networks(base_url: str) -> bool:
    """Whether the workflow may talk to this origin over http.

    IPC's workflow validator rejects an http origin unless the workflow opts in
    ("public workflow endpoints must use https"), and the hosted sandbox
    injects exactly that shape: BENCHMARK_BASE_URL is the platform's own gateway
    alias, http://<platform-host>.tsecbench.gw, because no public egress
    exists. Inside the sandbox the same opt-in also allows the gateway's
    private address, which is the only address it has.

    An explicit IPC_HOSTED_ALLOW_PRIVATE always wins, so an operator can force
    either answer.
    """

    explicit = (os.environ.get("IPC_HOSTED_ALLOW_PRIVATE") or "").strip()
    if explicit:
        return flag_truthy("IPC_HOSTED_ALLOW_PRIVATE")
    parsed = urlsplit(base_url)
    host = (parsed.hostname or "").lower()
    decided = parsed.scheme == "http" or host.endswith(".tsecbench.gw")
    if decided:
        log(
            "task origin is http or a platform gateway alias; "
            "the workflow may use a private address"
        )
    return decided


def confirm_workflow(workflow_id: str) -> None:
    preview = retry(
        lambda: request("GET", "/api/ops/workflows/" + workflow_id + "/confirmation"),
        "confirmation preview",
    )
    if not preview.get("ready"):
        raise SystemExit(
            "workflow is missing required secrets: " + repr(preview.get("missing_secrets"))
        )
    retry(
        lambda: request(
            "POST",
            "/api/ops/workflows/" + workflow_id + "/confirm",
            {"confirmation_phrase": preview["confirmation_phrase"]},
        ),
        "confirm workflow",
    )
    log("workflow confirmed")


def preflight(workflow_id: str) -> dict:
    report = retry(
        lambda: request("POST", "/api/workflows/" + workflow_id + "/preflight"),
        "preflight",
    )
    count = int(report.get("challenge_count") or 0)
    remote = int(report.get("remote_count") or 0)
    log(
        "preflight: "
        + str(count)
        + " challenges ("
        + str(remote)
        + " with containers), limits "
        + json.dumps(report.get("limits") or {}),
    )
    for challenge in report.get("challenges") or []:
        log(
            "  challenge "
            + str(challenge.get("external_id"))
            + " ["
            + str(challenge.get("category"))
            + "] "
            + ("solved" if challenge.get("solved") else "pending")
            + " "
            + str(challenge.get("title") or "")[:80],
        )
    if count <= 0:
        raise SystemExit("the platform returned an empty challenge list")
    return report


def existing_run(workflow_id: str) -> str:
    runs = retry(lambda: request("GET", "/api/runs?limit=50"), "list runs")["runs"]
    for run in runs:
        if run.get("workflow_id") != workflow_id:
            continue
        if str(run.get("status")) in TERMINAL:
            continue
        return str(run["id"])
    return ""


def start_run(workflow_id: str) -> str:
    run_id = existing_run(workflow_id)
    if run_id:
        log("resuming existing run " + run_id)
        return run_id
    key = "hosted-" + workflow_idempotency_token()
    snapshot = retry(
        lambda: request(
            "POST",
            "/api/workflows/" + workflow_id + "/start",
            {"idempotency_key": key},
        ),
        "start run",
    )
    run = snapshot.get("run") or {}
    run_id = str(run.get("id") or "")
    if not run_id:
        raise SystemExit("start did not return a run id")
    log(
        "run started "
        + run_id
        + " status="
        + str(run.get("status"))
        + " challenges="
        + str(len(snapshot.get("challenges") or [])),
    )
    return run_id


def write_status(snapshot: dict) -> None:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        (STATE_DIR / "status.json").write_text(
            json.dumps(snapshot, ensure_ascii=False)[:400000], encoding="utf-8"
        )
    except OSError:
        pass


def summarise(snapshot: dict) -> str:
    run = snapshot.get("run") or {}
    challenges = snapshot.get("challenges") or []
    solved = sum(1 for item in challenges if item.get("state") in SOLVED)
    remote = (snapshot.get("resource_capacity") or {}).get("remote") or {}
    capacity = snapshot.get("capacity") or {}
    return (
        "status="
        + str(run.get("status"))
        + " solved="
        + str(solved)
        + "/"
        + str(len(challenges))
        + " containers="
        + str(remote.get("used"))
        + "/"
        + str(remote.get("limit"))
        + " solving="
        + str(capacity.get("solving"))
    )


def resume_blocked(run_id: str, revision: int) -> None:
    try:
        request(
            "POST",
            "/api/runs/" + run_id + "/resume",
            {"revision": int(revision)},
        )
        log("asked the run to resume")
    except ApiError as exc:
        log("resume failed: " + str(exc))


def supervise(run_id: str) -> int:
    last = ""
    last_log = 0.0
    blocked_since = 0.0
    while True:
        try:
            snapshot = retry(lambda: request("GET", "/api/runs/" + run_id), "run snapshot")
        except ApiError as exc:
            if exc.permanent:
                raise
            log("snapshot failed: " + str(exc))
            time.sleep(POLL_SECONDS)
            continue
        write_status(snapshot)
        line = summarise(snapshot)
        now = time.time()
        if line != last or now - last_log >= HEARTBEAT_SECONDS:
            log(line)
            last = line
            last_log = now
        run = snapshot.get("run") or {}
        status = str(run.get("status"))
        if status in TERMINAL:
            log("run reached terminal state " + status)
            if status == "failed":
                return 1
            return 0
        if status == "blocked":
            now = time.time()
            if not blocked_since:
                blocked_since = now
            elif now - blocked_since > 180:
                resume_blocked(run_id, run.get("revision") or 0)
                blocked_since = now
        else:
            blocked_since = 0.0
        time.sleep(POLL_SECONDS)


def normalise_base_url(raw: str) -> str:
    """Reduce the injected task URL to the origin the workflow requires.

    The platform hands out the API root, and the TSecBench workflow validator
    only accepts an origin. The adapter already ignores the path when it builds
    its client, so dropping it here keeps both halves consistent instead of
    failing a run over a trailing "/openapi" nobody uses.
    """

    value = (raw or "").strip().rstrip("/")
    if not value:
        return ""
    parsed = urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise SystemExit("BENCHMARK_BASE_URL is not an http(s) URL: " + value)
    origin = parsed.scheme + "://" + parsed.netloc
    if origin != value:
        log("BENCHMARK_BASE_URL reduced to its origin: " + origin)
    return origin


def main() -> int:
    if not flag_autostart():
        log("IPC_HOSTED_AUTOSTART=0, leaving the run to an operator")
        return 0
    base_url = normalise_base_url(os.environ.get("BENCHMARK_BASE_URL") or "")
    token = (os.environ.get("BENCHMARK_TOKEN") or "").strip()
    if not base_url or not token:
        print(
            "[autopilot] BENCHMARK_BASE_URL and BENCHMARK_TOKEN are required; "
            "the platform injects them when the hosted task starts",
            file=sys.stderr,
            flush=True,
        )
        return 2
    log("task " + base_url + " token " + hashlib.sha256(token.encode()).hexdigest()[:8])
    wait_for_server()
    workflow_id = ensure_workflow(base_url, token)
    confirm_workflow(workflow_id)
    preflight(workflow_id)
    run_id = start_run(workflow_id)
    return supervise(run_id)


def flag_truthy_default(name: str, default: bool) -> bool:
    value = (os.environ.get(name) or "").strip().lower()
    if not value:
        return default
    return value in {"1", "true", "yes", "on"}


def flag_truthy(name: str) -> bool:
    value = (os.environ.get(name) or "").strip().lower()
    return value in {"1", "true", "yes", "on"}


def flag_autostart() -> bool:
    value = (os.environ.get("IPC_HOSTED_AUTOSTART") or "1").strip().lower()
    return value not in {"0", "false", "no", "off"}


if __name__ == "__main__":
    raise SystemExit(main())
