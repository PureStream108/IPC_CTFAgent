"""Fixture TSecBench platform for rehearsing the hosted image.

It implements just enough of the public OpenAPI to prove that the image
bootstraps by itself: list challenges, start a container, close it, submit a
flag. Use it to check an image before uploading it to the platform:

    python hosted/rehearse_platform.py --port 8899 --challenges 6
    docker run --rm -e BENCHMARK_BASE_URL=http://host.docker.internal:8899 \
        -e BENCHMARK_TOKEN=rehearsal-token -e IPC_HOSTED_ALLOW_PRIVATE=1 \
        -e IPC_LLM_API_KEY=sk-placeholder ipc-tsecbench:latest

The fixture prints one line per platform call, so the container log shows the
list/start/close traffic the real platform would see. It is a rehearsal tool,
not part of the graded image.
"""

from __future__ import annotations

import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

LOCK = threading.Lock()
STATE: dict = {"started": {}, "closed": 0, "submitted": 0, "listed": 0}


def challenge_set(count: int) -> list[dict]:
    items = []
    for index in range(count):
        code = "rehearsal-" + str(index + 1).zfill(2)
        items.append(
            {
                "unique_code": code,
                "description": "Rehearsal challenge " + str(index + 1) + ". The flag is flag{rehearsal-" + str(index + 1) + "}.",
                "difficulty": ("easy", "medium", "hard")[index % 3],
                "level": index + 1,
                "total_score": 300,
                "flag_count": 1,
                "correct_flag_count": 0,
                "is_completed": False,
                "container_status": "stopped",
                "container_addr": [],
            }
        )
    return items


class Handler(BaseHTTPRequestHandler):
    challenges: list[dict] = []

    def _send(self, status: int, payload) -> None:
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorised(self) -> bool:
        return bool(self.headers.get("BENCHMARK_TOKEN"))

    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path == "/state":
            with LOCK:
                self._send(200, dict(STATE))
            return
        if parsed.path == "/openapi/v1/challenges":
            if not self._authorised():
                self._send(401, {"code": "unauthorized", "message": "missing token"})
                return
            with LOCK:
                STATE["listed"] += 1
                active = set(STATE["started"])
            items = []
            for item in self.challenges:
                view = dict(item)
                if item["unique_code"] in active:
                    view["container_status"] = "available"
                    view["container_addr"] = ["127.0.0.1:1" + item["unique_code"][-2:]]
                items.append(view)
            print("[fixture] list challenges -> " + str(len(items)), flush=True)
            self._send(200, items)
            return
        if parsed.path == "/openapi/v1/challenges/hint":
            self._send(200, {"hint": None})
            return
        self._send(404, {"code": "not_found", "message": "unknown path"})

    def do_POST(self) -> None:
        parsed = urlsplit(self.path)
        length = int(self.headers.get("Content-Length", "0") or 0)
        body = json.loads(self.rfile.read(length) or b"{}") if length else {}
        if not self._authorised():
            self._send(401, {"code": "unauthorized", "message": "missing token"})
            return
        code = (parse_qs(parsed.query).get("unique_code") or [body.get("unique_code") or ""])[0]
        if parsed.path == "/openapi/v1/challenges/start":
            with LOCK:
                if len(STATE["started"]) >= 3 and code not in STATE["started"]:
                    self._send(409, {"code": "invalid_state", "message": "已达到上限: 3 active containers"})
                    return
                STATE["started"][code] = time.time()
            print("[fixture] start " + code + " -> active " + str(len(STATE["started"])), flush=True)
            self._send(200, {"unique_code": code, "container_addr": ["127.0.0.1:1" + code[-2:]]})
            return
        if parsed.path == "/openapi/v1/challenges/close":
            with LOCK:
                STATE["started"].pop(code, None)
                STATE["closed"] += 1
            print("[fixture] close " + code, flush=True)
            self._send(200, {"unique_code": code, "closed": True})
            return
        if parsed.path == "/openapi/v1/challenges/submit":
            with LOCK:
                STATE["submitted"] += 1
            print("[fixture] submit " + str(code) + " -> " + str(body.get("flag"))[:60], flush=True)
            self._send(200, {
                "correct": False, "awarded": 0, "cumulative_score": 0,
                "correct_flag_count": 0, "total_flag_count": 1, "matched_flag_index": None,
            })
            return
        self._send(404, {"code": "not_found", "message": "unknown path"})

    def log_message(self, *_args) -> None:
        return


def main() -> int:
    parser = argparse.ArgumentParser(description="Fixture TSecBench platform")
    parser.add_argument("--port", type=int, default=8899)
    parser.add_argument("--challenges", type=int, default=6)
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()
    Handler.challenges = challenge_set(max(1, args.challenges))
    print("[fixture] listening on " + args.host + ":" + str(args.port) + " with " + str(len(Handler.challenges)) + " challenges", flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
