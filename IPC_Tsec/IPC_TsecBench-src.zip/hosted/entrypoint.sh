#!/bin/sh
# Hosted TSecBench entrypoint: PostgreSQL -> config -> migrations -> IPC -> autopilot.
#
# The TSecBench hosted sandbox starts the image and expects the program to begin
# solving by itself, so every step below is unattended. Nothing here needs a
# docker daemon: Members run in this container through IPC_ALLOW_LOCAL_SANDBOX.
set -eu

# Standard image contract: an explicit command replaces the boot sequence, so
# "docker run --rm -it <image> bash" inspects the image instead of starting a
# database nobody asked for.
if [ "$#" -gt 0 ]; then
  exec "$@"
fi

APP_ROOT="${IPC_ROOT:-/app}"
PGDATA="${IPC_PGDATA:-/var/lib/ipc-postgres}"
PGLOG="${IPC_PGLOG:-/var/log/ipc-postgres.log}"
PORT="${IPC_PORT:-8000}"
export IPC_ROOT="$APP_ROOT"
export IPC_ARTIFACT_ROOT="${IPC_ARTIFACT_ROOT:-$APP_ROOT/data/artifacts}"
export IPC_DATABASE_URL="${IPC_DATABASE_URL:-postgresql://ipc:ipc@127.0.0.1:5432/ipc}"
export IPC_ALLOW_LOCAL_SANDBOX="${IPC_ALLOW_LOCAL_SANDBOX:-1}"
export PYTHONUNBUFFERED=1
export PYTHONPATH="$APP_ROOT${PYTHONPATH:+:$PYTHONPATH}"

mkdir -p "$IPC_ARTIFACT_ROOT" "$APP_ROOT/data/hosted"

say() { printf '[entrypoint] %s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }

# ---------------------------------------------------------------- PostgreSQL
PG_BIN="$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -n 1)"
if [ -z "$PG_BIN" ]; then
  say "postgres binaries are missing from the image" >&2
  exit 1
fi

if [ ! -s "$PGDATA/PG_VERSION" ]; then
  say "initialising a disposable database cluster in $PGDATA"
  mkdir -p "$PGDATA" "$(dirname "$PGLOG")"
  chown -R postgres:postgres "$PGDATA" "$(dirname "$PGLOG")"
  su postgres -s /bin/sh -c "$PG_BIN/initdb -D '$PGDATA' -U ipc --auth=trust --encoding=UTF8 --locale=C" >/dev/null
fi

chown -R postgres:postgres "$PGDATA" "$(dirname "$PGLOG")" 2>/dev/null || true
say "starting PostgreSQL on 127.0.0.1:5432"
su postgres -s /bin/sh -c "$PG_BIN/pg_ctl -D '$PGDATA' -l '$PGLOG' -w -t 120 -o '-c listen_addresses=127.0.0.1 -p 5432' start" >/dev/null
su postgres -s /bin/sh -c "$PG_BIN/createdb -h 127.0.0.1 -p 5432 -U ipc ipc" >/dev/null 2>&1 || true

# ------------------------------------------------------------- configuration
say "rendering configuration from the runtime environment"
python -m hosted.bootstrap_config

say "registering the bundled local skill"
python -m hosted.install_skills || say "local skill registration skipped"

say "applying database migrations"
cd "$APP_ROOT"
alembic upgrade head

# ------------------------------------------------------------------ IPC server
say "starting IPC on 0.0.0.0:$PORT"
python -m uvicorn backend.server.app:app --host 0.0.0.0 --port "$PORT" --log-level info &
UVICORN_PID=$!

shutdown() {
  say "shutting down"
  kill -TERM "$UVICORN_PID" 2>/dev/null || true
  wait "$UVICORN_PID" 2>/dev/null || true
  su postgres -s /bin/sh -c "$PG_BIN/pg_ctl -D '$PGDATA' -m fast stop" >/dev/null 2>&1 || true
}
trap 'shutdown; exit 143' TERM INT

# ------------------------------------------------------------------ autopilot
set +e
python -m hosted.autopilot
RC=$?
set -e
say "autopilot exited with $RC"
shutdown
# The hosted task is over once the run is terminal; keep the container alive a
# little so the platform can collect logs before it is torn down.
exit "$RC"
