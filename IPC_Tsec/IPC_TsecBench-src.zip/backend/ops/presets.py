"""Built-in platform workflow registry; legacy imports remain supported."""
from copy import deepcopy

from backend.platform.gzctf.workflow import GZCTF_TEMPLATE_VERSION, GZCTFWorkflowInput
from backend.platform.gzctf.workflow import TEMPLATE as GZCTF_TEMPLATE
from backend.platform.tsecbench.workflow import TEMPLATE as TSECBENCH_TEMPLATE
from backend.platform.tsecbench.workflow import (
    TSECBENCH_TEMPLATE_VERSION,
    TSECBenchWorkflowInput,
)

DEFAULT_WORKFLOW_TEMPLATE = "gzctf"


def workflow_templates() -> list[dict]:
    return deepcopy([GZCTF_TEMPLATE, TSECBENCH_TEMPLATE])


def workflow_preset(template_id: str) -> dict | None:
    """Return one built-in preset with the IPC personalization contract."""
    for template in workflow_templates():
        if template["id"] == template_id:
            return template
    return None


def preset_setup_prompt(template_id: str) -> str:
    preset = workflow_preset(template_id)
    if not preset:
        raise KeyError(template_id)
    return str((preset.get("ipc_setup") or {}).get("prompt") or "")


__all__ = [
    "DEFAULT_WORKFLOW_TEMPLATE",
    "GZCTF_TEMPLATE_VERSION",
    "TSECBENCH_TEMPLATE_VERSION",
    "GZCTFWorkflowInput",
    "TSECBenchWorkflowInput",
    "preset_setup_prompt",
    "workflow_preset",
    "workflow_templates",
]
