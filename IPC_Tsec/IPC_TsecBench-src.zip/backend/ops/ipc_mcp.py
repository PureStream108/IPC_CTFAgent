from __future__ import annotations

import logging
import re
import threading
from collections.abc import Callable
from typing import Any

from mcp.server.fastmcp import Context
from mcp.server.transport_security import TransportSecuritySettings

from backend.blackboard import edge_store, graph_store
from backend.core.config import CATEGORIES
from backend.core.ipc import (
    FlagConflictError,
    accept_verified_flag,
    assert_flag_compatible,
)
from backend.core.postprocess_store import (
    complete_existing_job,
    enqueue_postprocess,
)
from backend.core.state import AppState
from backend.core.wp_writer import persist_validated_writeup, write_wp_content
from backend.mcp.mcp_server import MCPServer, create_mcp_server
from backend.ops.store import OpsStore
from backend.ops.tools import OpsToolError, OpsToolExecutor

_recovery_logger = logging.getLogger(__name__)

_SESSION_ID_RE = re.compile(r"^ops_[a-f0-9]{16}$")
_SENSITIVE_FIELD_RE = re.compile(
    r"(?i)\b(?:authorization|api[ _-]?key|token|cookie|password|secret)\b\s*[:=]\s*[^\s,;]+"
)
_COMPETITION_SERVICE_LOCK = threading.Lock()


def build_ipc_mcp(state_provider: Callable[[], AppState]) -> MCPServer:
    """Build the IPC lifecycle MCP exposed to the Claude Code sidecar.

    This server is intentionally separate from Claude's native prompt.  Tool
    descriptions are the contract: start IPC's distributed solver before CTF
    work, record material actions in its logs, and finalize it with a Markdown writeup.  The
    app state is obtained lazily because the enclosing FastAPI application only
    creates it during its lifespan.
    """

    server = create_mcp_server(
        "ipc",
        """Operate the live IPC CTF workspace. For a CTF challenge, call
ipc_start_challenge before analysis so that activity is linked to a project and
the distributed IPC Members are queued. Use ipc_solver_status to observe Docker
startup and Member dispatch, and ipc_stop_challenge to interrupt them.
Use ipc_project_activity for material findings. When a flag is verified, call
ipc_finalize_challenge with the flag and a complete Markdown writeup; this is
what makes the IPC Logs and WP export pages contain the completed work. Do not
put API keys, cookies, tokens, or passwords in activity summaries. The host
tool is intentionally host-root and should only be used for an explicit
operator request.""",
    )
    tools = _Tools(state_provider)

    @server.tool(name="ipc_gzctf_workflow", description=(
        "Create or update the built-in default GZCTF workflow. Supply only platform base_url, "
        "game_id and optional name/team_id/ends_at/remote_concurrency/attachment_base_url. "
        "No HTTP mappings or platform probing are needed. Ask ipc_question for any missing "
        "base_url or game_id; after creating the draft, ask for gzctf_token (or "
        "gzctf_username/gzctf_password) with ipc_question. Return the draft for normal "
        "confirmation."
    ))
    def gzctf_workflow(settings: dict[str, Any], workflow_id: str | None = None) -> dict[str, Any]:
        from backend.ops.service import OpsAgentService

        if "secrets" in settings:
            raise ValueError("use the structured workflow secret store for credentials")
        state = state_provider()
        service = getattr(state, "ops_agent_service", None) or OpsAgentService(state)
        return service.configure_gzctf_workflow(settings, workflow_id=workflow_id)

    @server.tool(name="ipc_tsecbench_workflow", description=(
        "Create or update the built-in default TSecBench benchmark workflow. Supply only "
        "the platform base_url and optional name/team_id/remote_concurrency. No HTTP "
        "mappings or platform probing are needed. The benchmark token goes into the "
        "workflow secret store as benchmark_token; ask ipc_question with "
        "secret_name=benchmark_token after creating the draft when it is missing. "
        "Return the draft for normal confirmation."
    ))
    def tsecbench_workflow(settings: dict[str, Any], workflow_id: str | None = None) -> dict[str, Any]:
        from backend.ops.service import OpsAgentService

        if "secrets" in settings:
            raise ValueError("use the structured workflow secret store for credentials")
        state = state_provider()
        service = getattr(state, "ops_agent_service", None) or OpsAgentService(state)
        return service.configure_tsecbench_workflow(settings, workflow_id=workflow_id)

    @server.tool(name="ipc_question", description="Ask for missing platform information. Return to the operator while pending; call again with the same operation key to read the answer. Credentials go into the workflow secret store; use secret_name=benchmark_token for a native TSecBench workflow, or secret_name=gzctf_token (or gzctf_username/gzctf_password) for native GZCTF.")
    def question(operation_key: str, title: str, options: list[str] | None = None,
                 workflow_id: str | None = None, secret_name: str | None = None,
                 ctx: Context | None = None) -> dict:
        from backend.ops.questions import QuestionStore
        session_id = _session_id_from_context(ctx)
        if not session_id:
            raise ValueError("question requires an IPC session")
        return QuestionStore(state_provider()).create(session_id=session_id, operation_key=operation_key,
                    title=title, options=options, workflow_id=workflow_id, secret_name=secret_name)

    @server.tool(
        name="ipc_question_result",
        description=(
            "Read the durable answer for an IPC question after the operator responds. "
            "The question must belong to the current IPC session; sensitive answers are "
            "returned only as a workflow secret reference."
        ),
    )
    def question_result(question_id: str, ctx: Context | None = None) -> dict[str, Any]:
        from backend.ops.questions import QuestionStore

        session_id = _session_id_from_context(ctx)
        if not session_id:
            raise ValueError("question requires an IPC session")
        return QuestionStore(state_provider()).result(question_id, session_id)

    @server.tool(
        name="ipc_platform_preflight",
        description=(
            "Run the confirmed platform workflow preflight through IPC. This checks "
            "authentication and adapter capabilities before any challenge import or "
            "Member allocation is started."
        ),
    )
    def platform_preflight(workflow_id: str) -> dict[str, Any]:
        return tools.platform_preflight(workflow_id)

    @server.tool(
        name="ipc_start_platform",
        description=(
            "Start one confirmed platform workflow through IPC's CompetitionService. "
            "The idempotency key is required; preflight, import, and the ten Member "
            "seat allocation are owned by IPC."
        ),
    )
    def start_platform(
        workflow_id: str,
        idempotency_key: str,
        select: list[str] | None = None,
    ) -> dict[str, Any]:
        return tools.start_platform(workflow_id, idempotency_key, select)

    @server.tool(
        name="ipc_platform_status",
        description="Read a platform run snapshot and current IPC Member seat allocation.",
    )
    def platform_status(run_id: str) -> dict[str, Any]:
        return tools.platform_status(run_id)

    @server.tool(
        name="ipc_list_projects",
        description="List live IPC projects and their status, including whether a task sandbox is active.",
    )
    def list_projects() -> dict[str, Any]:
        return tools.list_projects()

    @server.tool(
        name="ipc_start_challenge",
        description=(
            "Create and link a live IPC project for the current CTF task, then queue IPC's "
            "distributed Members without blocking on Docker startup. For category=pentest, "
            "pass scope, constraints and goals so the Pentest board is populated."
        ),
    )
    def start_challenge(
        title: str,
        category: str,
        origin: str,
        goal: str = "Solve the challenge and document a reproducible writeup.",
        external_id: str | None = None,
        scope: str | None = None,
        constraints: list[str] | None = None,
        goals: list[str] | None = None,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        return tools.start_challenge(
            title=title,
            category=category,
            origin=origin,
            goal=goal,
            external_id=external_id,
            scope=scope,
            constraints=constraints,
            goals=goals,
            session_id=_session_id_from_context(ctx),
        )

    @server.tool(
        name="ipc_start_solver",
        description="Queue IPC's distributed Members for an existing project and return its startup phase immediately.",
    )
    def start_solver(project_id: str) -> dict[str, Any]:
        return tools.start_solver(project_id)

    @server.tool(
        name="ipc_solver_status",
        description="Inspect project status, startup phase/error, task-sandbox availability, and active Members.",
    )
    def solver_status(project_id: str) -> dict[str, Any]:
        return tools.solver_status(project_id)

    @server.tool(
        name="ipc_stop_challenge",
        description="Interrupt IPC Members, stop the task sandbox, and leave the project resumable.",
    )
    def stop_challenge(project_id: str) -> dict[str, Any]:
        return tools.stop_challenge(project_id)

    @server.tool(
        name="ipc_project_activity",
        description=(
            "Record a concise, non-sensitive CTF finding or decision in an IPC project's "
            "durable project log."
        ),
    )
    def project_activity(project_id: str, event: str, summary: str) -> dict[str, Any]:
        return tools.project_activity(project_id, event, summary)

    @server.tool(
        name="ipc_write_writeup",
        description=(
            "Save a Markdown writeup for an IPC project without marking the challenge complete. "
            "Use ipc_finalize_challenge after a flag is verified."
        ),
    )
    def write_writeup(project_id: str, markdown: str) -> dict[str, Any]:
        return tools.write_writeup(project_id, markdown)

    @server.tool(
        name="ipc_finalize_challenge",
        description=(
            "Record a verified flag, save the complete Markdown writeup, and mark the IPC project "
            "completed so it appears in WP export."
        ),
    )
    def finalize_challenge(project_id: str, flag: str, markdown: str) -> dict[str, Any]:
        return tools.finalize_challenge(project_id, flag, markdown)

    @server.tool(
        name="ipc_task_sandbox_health",
        description="Run a harmless health probe in an active IPC task sandbox and record its result.",
    )
    def task_sandbox_health(project_id: str) -> dict[str, Any]:
        return tools.task_sandbox_health(project_id)

    @server.tool(
        name="ipc_task_sandbox_exec",
        description=(
            "Run a command as the task-container user in an active IPC task sandbox and record "
            "command metadata in the project log."
        ),
    )
    def task_sandbox_exec(project_id: str, command: str, timeout: int = 60) -> dict[str, Any]:
        return tools.task_sandbox_exec(project_id, command, timeout)

    @server.tool(
        name="ipc_host_exec",
        description=(
            "Execute a command as root on the Docker host. This is the highest-privilege IPC tool; "
            "use it only when the operator explicitly requested a host-level diagnostic or change."
        ),
    )
    def host_exec(command: str, timeout: int = 60) -> dict[str, Any]:
        return tools.host_exec(command, timeout)

    security = server.settings.transport_security
    if security is None:
        security = TransportSecuritySettings()
        server.settings.transport_security = security
    if "ipc-app:8000" not in security.allowed_hosts:
        security.allowed_hosts.append("ipc-app:8000")
    if "testserver" not in security.allowed_hosts:
        security.allowed_hosts.append("testserver")
    return server


class _Tools:
    def __init__(self, state_provider: Callable[[], AppState]) -> None:
        self._state_provider = state_provider

    @property
    def state(self) -> AppState:
        return self._state_provider()

    def list_projects(self) -> dict[str, Any]:
        return OpsToolExecutor(self.state).list_task_sandboxes()

    def _competition(self):
        """Return the single process-wide competition coordinator used by IPC.

        The FastAPI lifespan normally creates this service.  The lazy fallback
        keeps direct MCP embedding safe while preserving one coordinator per
        AppState, so two MCP calls cannot create competing allocators.
        """
        service = getattr(self.state, "competition", None)
        if service is not None:
            return service
        with _COMPETITION_SERVICE_LOCK:
            service = getattr(self.state, "competition", None)
            if service is None:
                from backend.competition.service import CompetitionService

                service = CompetitionService(self.state)
                self.state.competition = service
                service.start_worker()
        return service

    def platform_preflight(self, workflow_id: str) -> dict[str, Any]:
        workflow_id = _required_text(workflow_id, "workflow_id", 200)
        try:
            result = self._competition().preflight(workflow_id)
        except (KeyError, PermissionError, ValueError, RuntimeError) as exc:
            return {"ok": False, "workflow_id": workflow_id, "error": str(exc)}
        return {"ok": True, "allocator": "ipc", **result}

    def start_platform(
        self,
        workflow_id: str,
        idempotency_key: str,
        select: list[str] | None = None,
    ) -> dict[str, Any]:
        workflow_id = _required_text(workflow_id, "workflow_id", 200)
        idempotency_key = _required_text(idempotency_key, "idempotency_key", 200)
        if len(idempotency_key) < 8:
            return {
                "ok": False,
                "workflow_id": workflow_id,
                "error": "idempotency_key must contain at least 8 characters",
            }
        selected = [str(item) for item in select] if select is not None else None
        try:
            snapshot = self._competition().start(
                workflow_id, idempotency_key, select=selected
            )
        except (KeyError, PermissionError, ValueError, RuntimeError) as exc:
            return {"ok": False, "workflow_id": workflow_id, "error": str(exc)}
        return {
            "ok": True,
            "allocator": "ipc",
            "workflow_id": workflow_id,
            "run": snapshot.get("run", snapshot),
            "capacity": snapshot.get("capacity"),
            "message": (
                "IPC owns platform synchronization and Member allocation. "
                "Poll ipc_platform_status for the durable run snapshot."
            ),
        }

    def platform_status(self, run_id: str) -> dict[str, Any]:
        run_id = _required_text(run_id, "run_id", 200)
        try:
            service = self._competition()
            run = service.store.run_snapshot(run_id)
            members = service.store.member_snapshot(run_id)
        except (KeyError, ValueError) as exc:
            return {"ok": False, "run_id": run_id, "error": str(exc)}
        return {"ok": True, "allocator": "ipc", "run": run, "members": members}

    def start_challenge(
        self,
        *,
        title: str,
        category: str,
        origin: str,
        goal: str,
        external_id: str | None,
        scope: str | None = None,
        constraints: list[str] | None = None,
        goals: list[str] | None = None,
        session_id: str | None,
    ) -> dict[str, Any]:
        normalized_category = str(category).strip().lower()
        if normalized_category not in CATEGORIES:
            return {"ok": False, "error": f"category must be one of {', '.join(CATEGORIES)}"}
        startup_error = self._startup_error()
        if startup_error:
            return {"ok": False, "error": startup_error}
        title = _required_text(title, "title", 240)
        origin = _required_text(origin, "origin", 12_000)
        goal = _required_text(goal, "goal", 12_000)
        ext = str(external_id).strip()[:240] if external_id else None
        pentest_setup = None
        if normalized_category == "pentest":
            pentest_setup, setup_error = _pentest_setup(
                scope=scope, constraints=constraints, goals=goals, origin=origin, goal=goal
            )
            if setup_error:
                return {"ok": False, "error": setup_error}
        with self.state.db.connect() as conn:
            project_id = graph_store.create_project(
                conn,
                title,
                origin,
                goal,
                normalized_category,
                external_id=ext,
                pentest_setup=pentest_setup,
            )
        self.state.logger.project(
            "ops_agent_project_started",
            project_id,
            title=title,
            category=normalized_category,
            source="claude-code-mcp",
        )
        if session_id:
            OpsStore(self.state.root, self.state.db).link_session_project(session_id, project_id)
        result = self.start_solver(project_id)
        result["message"] = (
            "Project is linked and IPC solver startup is queued. Poll ipc_solver_status, "
            "record findings with ipc_project_activity, and finalize with ipc_finalize_challenge."
        )
        return result

    def start_solver(self, project_id: str) -> dict[str, Any]:
        self._require_project(project_id)
        startup_error = self._startup_error()
        if startup_error:
            return {"ok": False, "project_id": project_id, "error": startup_error}
        try:
            status = self.state.orchestrator.start_project_async(project_id)
        except (RuntimeError, ValueError) as exc:
            return {"ok": False, "project_id": project_id, "error": str(exc)}
        return {"ok": True, **status}

    def solver_status(self, project_id: str) -> dict[str, Any]:
        self._require_project(project_id)
        if self.state.orchestrator is not None:
            status = self.state.orchestrator.runtime_status(project_id)
        else:
            with self.state.db.connect() as conn:
                row = graph_store.get_project_row(conn, project_id)
            status = {
                "project_id": project_id,
                "status": str(row["status"]),
                "phase": str(row["runtime_phase"] or "idle"),
                "error": row["runtime_error"],
            }
        with self.state.db.connect() as conn:
            active_members = [
                row["name"]
                for row in conn.execute(
                    "SELECT name FROM agents WHERE project_id = %s AND role = 'member' AND state = 'active' ORDER BY name",
                    (project_id,),
                ).fetchall()
            ]
        return {
            "ok": True,
            **status,
            "sandbox_active": project_id in set(self.state.pool.active_projects()),
            "active_members": active_members,
        }

    def stop_challenge(self, project_id: str) -> dict[str, Any]:
        self._require_project(project_id)
        with self.state.db.connect() as conn:
            row = graph_store.get_project_row(conn, project_id)
            if row["status"] == "solved":
                return {"ok": False, "project_id": project_id, "error": "solved projects cannot be stopped"}
            graph_store.set_status(conn, project_id, "stopped")
            graph_store.set_runtime_phase(conn, project_id, "stopped")
            conn.execute(
                "UPDATE intents SET worker = NULL, lease_owner = NULL, lease_token = NULL, "
                "lease_expires_at = NULL, last_heartbeat_at = NULL "
                "WHERE project_id = %s AND concluded_at IS NULL",
                (project_id,),
            )
            graph_store.clear_reason(conn, project_id)
        if self.state.orchestrator is not None:
            self.state.orchestrator.stop_project(project_id)
        self.state.logger.project("ops_agent_project_stopped", project_id, source="claude-code-mcp")
        return {"ok": True, "project_id": project_id, "status": "stopped", "phase": "stopped"}

    def project_activity(self, project_id: str, event: str, summary: str) -> dict[str, Any]:
        self._require_project(project_id)
        event = _required_text(event, "event", 120)
        summary = _safe_summary(summary)
        self.state.logger.llm(
            "ops_agent_activity",
            project_id,
            source="claude-code-mcp",
            activity=event,
            summary=summary,
        )
        return {"ok": True, "project_id": project_id, "event": event}

    def write_writeup(self, project_id: str, markdown: str) -> dict[str, Any]:
        self._require_project(project_id)
        try:
            path = write_wp_content(self.state.db, project_id, self.state.wp_dir, markdown)
        except (RuntimeError, ValueError) as exc:
            return {"ok": False, "error": str(exc)}
        self.state.logger.project("ops_agent_writeup_saved", project_id, path=path)
        return {"ok": True, "project_id": project_id, "wp_path": path}

    def finalize_challenge(self, project_id: str, flag: str, markdown: str) -> dict[str, Any]:
        self._require_project(project_id)
        try:
            flag = _required_text(flag, "flag", 2048)
        except ValueError as exc:
            return {"ok": False, "project_id": project_id, "error": str(exc)}
        rollback_file: Callable[[], None] | None = None
        try:
            with self.state.db.connect() as conn:
                assert_flag_compatible(conn, project_id, flag)
                path, rollback_file = persist_validated_writeup(
                    conn,
                    project_id,
                    self.state.wp_dir,
                    markdown,
                    expected_flag=flag,
                )
                source = conn.execute(
                    "SELECT id FROM facts WHERE project_id = %s AND id <> 'goal' "
                    "ORDER BY created_at DESC, id DESC LIMIT 1",
                    (project_id,),
                ).fetchone()
                source_id = source["id"] if source else "origin"
                edge_store.complete_goal_intent(
                    conn,
                    project_id,
                    [source_id],
                    "flag captured by IPC action agent",
                    "ops-agent",
                    "ops-agent",
                )
                accept_verified_flag(
                    conn,
                    project_id,
                    flag,
                    source="ops-agent",
                )
                enqueue_postprocess(conn, project_id)
                complete_existing_job(conn, project_id, "writeup")
                graph_store.set_runtime_phase(conn, project_id, "solved")
        except FlagConflictError as exc:
            return {"ok": False, "project_id": project_id, "conflict": True, "error": str(exc)}
        except (RuntimeError, ValueError) as exc:
            if rollback_file is not None:
                rollback_file()
            return {"ok": False, "project_id": project_id, "error": str(exc)}
        except Exception:
            if rollback_file is not None:
                rollback_file()
            raise
        if self.state.orchestrator is not None:
            self.state.orchestrator.on_flag_found(project_id)
        with self.state.db.connect() as conn:
            project = graph_store.get_project_row(conn, project_id)
        postprocess_status = project["postprocess_status"] if project is not None else "pending"
        self.state.logger.project(
            "ops_agent_challenge_finalized",
            project_id,
            source="claude-code-mcp",
            wp_path=path,
            flag_captured=True,
        )
        return {
            "ok": True,
            "project_id": project_id,
            "status": "solved",
            "postprocess_status": postprocess_status,
            "wp_path": path,
            "message": "Flag verified. Memory and archive processing continue asynchronously.",
        }

    def task_sandbox_health(self, project_id: str) -> dict[str, Any]:
        return self._run_project_tool(project_id, "task_sandbox_health")

    def task_sandbox_exec(self, project_id: str, command: str, timeout: int) -> dict[str, Any]:
        return self._run_project_tool(project_id, "task_sandbox_exec", command, timeout)

    def host_exec(self, command: str, timeout: int) -> dict[str, Any]:
        try:
            result = OpsToolExecutor(self.state).host_exec(command, timeout)
        except OpsToolError as exc:
            return {"ok": False, "error": str(exc), "privilege": "host-root"}
        self.state.logger.tool(
            "ops_agent_host_exec",
            "global",
            source="claude-code-mcp",
            privilege="host-root",
            ok=bool(result.get("ok")),
            exit_code=result.get("exit_code"),
            command_length=len(command) if isinstance(command, str) else 0,
        )
        return result

    def _run_project_tool(self, project_id: str, name: str, *args: Any) -> dict[str, Any]:
        self._require_project(project_id)
        executor = OpsToolExecutor(self.state)
        try:
            result = executor.execute(name, {"project_id": project_id, **_arguments_for(name, args)})
        except OpsToolError as exc:
            result = {"ok": False, "error": str(exc), "project_id": project_id}
        self.state.logger.tool(
            "ops_agent_task_exec",
            project_id,
            source="claude-code-mcp",
            tool=name,
            ok=bool(result.get("ok")),
            exit_code=result.get("exit_code"),
            command_length=(len(args[0]) if name == "task_sandbox_exec" and isinstance(args[0], str) else 0),
        )
        return result

    def _require_project(self, project_id: str) -> None:
        with self.state.db.connect() as conn:
            row = graph_store.get_project_row(conn, project_id)
        if row is None:
            raise ValueError(f"project not found: {project_id}")

    def _startup_error(self) -> str | None:
        errors = self.state.config.startup_errors()
        if errors:
            return "; ".join(errors)
        if self.state.orchestrator is None:
            return "IPC orchestrator is not running"
        return None


def _arguments_for(name: str, args: tuple[Any, ...]) -> dict[str, Any]:
    if name == "task_sandbox_health":
        return {}
    if name == "task_sandbox_exec":
        command, timeout = args
        return {"command": command, "timeout": timeout}
    raise ValueError(f"unexpected IPC tool: {name}")


def _required_text(value: Any, field: str, maximum: int) -> str:
    text = str(value).strip() if value is not None else ""
    if not text:
        raise ValueError(f"{field} is required")
    if len(text) > maximum:
        raise ValueError(f"{field} is limited to {maximum} characters")
    return text


def _pentest_setup(
    *,
    scope: str | None,
    constraints: list[str] | None,
    goals: list[str] | None,
    origin: str,
    goal: str,
) -> tuple[dict[str, Any] | None, str | None]:
    """Build the Pentest Setup payload for a project created over MCP.

    The scope falls back to origin and the goals fall back to the single goal
    text, so a plain ipc_start_challenge(category=pentest) still produces a
    board with a usable scope instead of an empty one. Validation runs here
    (not later inside create_project) so the caller gets a readable MCP error
    instead of a failed transaction.
    """

    from backend.pentest.models import Setup

    candidate = scope.strip() if isinstance(scope, str) else ""
    raw_scope = candidate or origin.strip()
    clean_constraints, error = _clean_list(constraints)
    if error:
        return None, f"invalid pentest setup: constraints {error}"
    clean_goals, error = _clean_list(goals)
    if error:
        return None, f"invalid pentest setup: goals {error}"
    if not clean_goals and goal.strip():
        clean_goals = [goal.strip()[:2000]]
    payload = {
        "scope": raw_scope[:8000],
        "constraints": clean_constraints,
        "goals": clean_goals,
    }
    try:
        return Setup.model_validate(payload).model_dump(), None
    except ValueError as exc:
        return None, f"invalid pentest setup: {exc}"


def _clean_list(values: list[str] | None) -> tuple[list[str], str | None]:
    """Trim, de-duplicate and bound a Pentest constraint/goal list.

    Over-long entries are rejected rather than truncated: a silently shortened
    constraint is worse than none, because it still reads like a complete rule
    when injected into every dispatch.
    """

    if not values:
        return [], None
    seen: list[str] = []
    for item in values:
        text = str(item).strip()
        if not text:
            continue
        if len(text) > 2000:
            return [], "entries must contain 1 to 2000 characters"
        if text not in seen:
            seen.append(text)
    if len(seen) > 40:
        return [], "at most 40 entries are allowed"
    return seen, None

def _safe_summary(value: Any) -> str:
    text = _required_text(value, "summary", 12_000)
    return _SENSITIVE_FIELD_RE.sub("[redacted-sensitive-field]", text)


def _session_id_from_context(ctx: Context | None) -> str | None:
    if ctx is None:
        return None
    try:
        request = ctx.request_context.request
        headers = getattr(request, "headers", None)
        value = headers.get("x-ipc-ops-session", "") if headers is not None else ""
    except Exception:
        _recovery_logger.debug('Error handled in _session_id_from_context', exc_info=True)
        return None
    return value if isinstance(value, str) and _SESSION_ID_RE.fullmatch(value) else None
