from __future__ import annotations

import logging
import os
import re
import shutil
import socket
import threading
import uuid
from pathlib import Path

from backend.blackboard import graph_store
from backend.blackboard.db import Database
from backend.core.config import AppConfig, load_config, save_config
from backend.core.logging_util import IPCLogger
from backend.mcp.mcp_client import MCPRegistry
from backend.memory.memory_mcp import build_memory_mcp
from backend.memory.memory_store import MemoryStore
from backend.platform.ret2shell import Ret2ShellClient
from backend.platform.ret2shell.mcp import build_ret2shell_mcp
from backend.sandbox.container_pool import ContainerPool
from backend.sandbox.network_manager import NetworkManager
from backend.sandbox.resource_limiter import TaskSlotLimiter
from backend.tools.catalog import ToolCatalog
from backend.tools.tool_mcp import build_tool_search_mcp
from backend.tools.tool_registry import ToolRegistry

_recovery_logger = logging.getLogger(__name__)

def _env_flag(name: str) -> bool:
    value = os.environ.get(name, "").strip().lower()
    return value in {"1", "true", "yes", "on"}


class AppState:
    def __init__(self, root: str | Path = ".", config_dir: Path | None = None):
        self.root = Path(root)
        configured_artifact_root = os.environ.get("IPC_ARTIFACT_ROOT", "").strip()
        self.artifact_root = (
            Path(configured_artifact_root).expanduser()
            if configured_artifact_root
            else self.root / "data" / "artifacts"
        )
        self.projects_dir = self.artifact_root / "projects"
        self.wp_dir = self.artifact_root / "writeups"
        self.logs_dir = self.artifact_root / "logs"
        self.export_dir = self.artifact_root / "exports"
        self.log_export_dir = self.export_dir / "logs"
        self.wp_export_dir = self.export_dir / "writeups"
        self.memory_export_dir = self.export_dir / "memory"
        self.instance_id = os.environ.get("IPC_INSTANCE_ID") or (
            f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"
        )
        self.config_dir = config_dir
        if _env_flag("IPC_CLEAN_START"):
            self._clean_runtime_state()
        self.config: AppConfig = load_config(config_dir)

        self.db = Database().configure()
        with self.db.connect() as conn:
            graph_store.reset_project_counter_if_empty(conn)
            self._reserve_existing_project_ids(conn)
        self.memory = MemoryStore(self.db, export_dir=None).configure()
        self.registry = ToolRegistry().load()
        self.catalog = ToolCatalog.load(self.registry)
        for directory in (
            self.projects_dir,
            self.wp_dir,
            self.logs_dir,
            self.log_export_dir,
            self.wp_export_dir,
            self.memory_export_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)
        self.export_lock = threading.RLock()
        self.logger = IPCLogger(
            self.logs_dir,
            enabled=self.config.log_enabled,
            project_filename_resolver=self.project_log_filename,
        )

        self.limiter = TaskSlotLimiter(
            max_concurrent_tasks=self.config.limits.max_concurrent_tasks,
            total_cpu=self.config.limits.total_cpu,
        )
        self.pool = ContainerPool(
            backend=self.config.runtime.sandbox_backend,
            workspace_root=self.projects_dir,
            limiter=self.limiter,
            network=self.config.limits.network,
            mem_limit=self.config.limits.mem_limit,
            pids_limit=self.config.limits.pids_limit,
        )
        self.network = NetworkManager(backend=self.config.runtime.sandbox_backend)

        self.mcps = MCPRegistry()
        from backend.skills.mcp import build_skills_mcp
        from backend.skills.store import SkillStore
        self.skills = SkillStore(self.artifact_root / "skills", Path("/opt/ipc-skills"))
        self.skills.bootstrap()
        self.mcps.register(build_skills_mcp(self.skills))
        self.mcps.register(build_memory_mcp(self.memory, catalog=self.catalog))
        self.mcps.register(build_tool_search_mcp(self.registry))
        self.ret2shell_client: Ret2ShellClient | None = None
        if os.getenv("IPC_R2S_USERNAME") or os.getenv("IPC_R2S_TOKEN"):
            self.ret2shell_client = Ret2ShellClient()
            self.mcps.register(build_ret2shell_mcp(self.ret2shell_client))

        self.orchestrator = None

    def _reserve_existing_project_ids(self, conn) -> None:
        """Keep a fresh database from reusing surviving workspace ids.

        PostgreSQL rows are durable, but the database can still be recreated
        (e.g. a replaced container volume) while project workspace directories
        on the shared Artifact root survive.  Reserve the largest surviving
        numeric ID so a newly created project never inherits old progress or
        artifacts merely because the database started empty.
        """
        if not self.projects_dir.is_dir():
            return
        highest = 0
        for entry in self.projects_dir.iterdir():
            if not entry.is_dir():
                continue
            match = re.fullmatch(r"proj_(\d+)", entry.name)
            if match:
                highest = max(highest, int(match.group(1)))
        if highest:
            conn.execute(
                "UPDATE counters SET value = GREATEST(value, %s) WHERE name = 'project'",
                (highest,),
            )

    def _clean_runtime_state(self) -> None:
        for target in (self.projects_dir, self.wp_dir, self.logs_dir):
            if not target.exists():
                continue
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=True)
            else:
                target.unlink(missing_ok=True)

    def reload_config(self) -> None:
        self.config = load_config(self.config_dir)
        self.logger.set_enabled(self.config.log_enabled)
        self.limiter.update_limits(
            max_concurrent_tasks=self.config.limits.max_concurrent_tasks,
            total_cpu=self.config.limits.total_cpu,
        )
        if self.orchestrator is not None:
            self.orchestrator.reload_config()

    def save_config(self) -> None:
        save_config(self.config, self.config_dir)
        self.logger.set_enabled(self.config.log_enabled)
        self.limiter.update_limits(
            max_concurrent_tasks=self.config.limits.max_concurrent_tasks,
            total_cpu=self.config.limits.total_cpu,
        )
        if self.orchestrator is not None:
            self.orchestrator.reload_config()

    def close(self) -> None:
        """Release resources owned by the application state."""
        try:
            self.registry.close()
        finally:
            try:
                self.memory.close()
            finally:
                self.db.close()

    def project_log_filename(self, project_id: str) -> str | None:
        try:
            with self.db.connect() as conn:
                return graph_store.project_log_filename(conn, project_id)
        except Exception:
            _recovery_logger.debug('Error handled in project_log_filename', exc_info=True)
            return project_id

    def attachments_dir(self, project_id: str) -> Path:
        d = self.projects_dir / project_id / "attachments"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def delete_project_files(self, project_id: str) -> None:
        target = (self.projects_dir / project_id).resolve()
        root = self.projects_dir.resolve()
        if target == root or root not in target.parents:
            raise ValueError(f"refusing to delete project path outside projects dir: {target}")
        shutil.rmtree(target, ignore_errors=True)
        self.logger.delete_project_logs(project_id)
