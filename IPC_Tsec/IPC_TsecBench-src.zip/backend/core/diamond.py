from __future__ import annotations

import logging
from dataclasses import dataclass

from backend.blackboard import edge_store, graph_store, node_store
from backend.core.config import AppConfig, MemberConfig
from backend.core.curator import SUGILITE, is_curator_project
from backend.core.difficulty import extra_members_for_difficulty, normalize_difficulty
from backend.core.logging_util import IPCLogger
from backend.core.wp_writer import WRITEUP_SYSTEM_PROMPT, generate_wp_content, write_wp
from backend.members.adapters import make_adapter

_recovery_logger = logging.getLogger(__name__)

BOOTSTRAP_DESC = "Bootstrap: Starting"


@dataclass
class Assignment:
    member: str
    intent_id: str
    is_initial: bool = False


class Diamond:
    def __init__(self, db, config: AppConfig, logger: IPCLogger):
        self.db = db
        self.config = config
        self.logger = logger
        self._pentest_tick_logged_at = 0.0


    def available_member_configs(self) -> list[MemberConfig]:
        return self.config.available_members()

    def _solver_members(self, project_id: str) -> list[MemberConfig]:
        members = self.available_member_configs()
        if is_curator_project(self.db, project_id):
            members = [member for member in members if member.name != SUGILITE]
        return members

    def _idle_members(self, project_id: str) -> list[MemberConfig]:
        """Members free to take new work on this project.

        Both fences matter: a Member already active on this project, and a
        Member holding a durable competition seat on a *different* challenge.
        """

        with self.db.connect() as conn:
            active = set(graph_store.active_member_names(conn, project_id))
        occupied = active | self._members_seated_elsewhere(project_id)
        return [m for m in self._solver_members(project_id) if m.name not in occupied]

    def _members_seated_elsewhere(self, project_id: str) -> set[str]:
        """Members holding a durable competition seat on another challenge.

        Without this the nomination only considered the current project, so a
        Member already seated elsewhere was picked, the orchestrator's seat
        fence refused the launch, the intent fell back to the primary, and the
        reinforcement silently never happened — while filling the log with
        ``legacy_member_blocked_by_competition``.

        Failure is deliberately non-fatal: with no competition tables (a plain
        standalone project, or the first boot of a migration) there are no
        seats to respect.
        """

        try:
            with self.db.connect() as conn:
                rows = conn.execute(
                    """SELECT DISTINCT a.member
                         FROM competition_assignments a
                         JOIN competition_challenges c ON c.id=a.challenge_id
                         JOIN competition_runs r ON r.id=a.run_id
                        WHERE a.released_at IS NULL
                          AND r.status NOT IN ('finished','stopped')
                          AND (c.project_id IS NULL OR c.project_id <> %s)""",
                    (project_id,),
                ).fetchall()
        except Exception:
            _recovery_logger.debug('Error handled in _members_seated_elsewhere', exc_info=True)
            return set()
        return {row["member"] for row in rows}


    def assign_initial(
        self, project_id: str, excluded_members: set[str] | None = None,
        preferred_member: str | None = None,
    ) -> Assignment | None:
        excluded = excluded_members or set()
        avail = [
            member for member in self._solver_members(project_id)
            if member.name not in excluded
        ]
        if not avail:
            return None
        initial = next(
            (m for m in avail if preferred_member and m.name == preferred_member),
            next((m for m in avail if m.name == "aventurine"), avail[0]),
        )
        with self.db.connect() as conn:
            graph_store.set_agent_state(conn, project_id, "diamond", "active")
            if not graph_store.link_exists(conn, project_id, "ipc", "diamond", "start"):
                graph_store.add_link(conn, project_id, "ipc", "diamond", "start")
            row = graph_store.get_project_row(conn, project_id)
            description = ("读取渗透任务板，核对明确的范围与约束，分解用户目标，然后用 pentest_plan_work 登记聚焦工作；"
                           "登记发现的资产与实际证据。只使用现有任务执行环境，不得把候选发现当作已验证结论。"
                           if row and row["category"] == "pentest" else BOOTSTRAP_DESC)
            intent = edge_store.create_intent(conn, project_id, ["origin"], description, "diamond")
            graph_store.add_agent(conn, project_id, initial.name, "member", state="active", start_fact_id="origin")
            graph_store.set_agent_state(conn, project_id, initial.name, "active")
            graph_store.add_link(conn, project_id, "diamond", initial.name, "assign")
            graph_store.add_link(conn, project_id, initial.name, f"intent:{intent.id}", "explore")
        self.logger.project("diamond_assign_initial", project_id, member=initial.name, intent=intent.id)
        return Assignment(member=initial.name, intent_id=intent.id, is_initial=True)


    def decide_reinforcements(self, project_id: str, report, available_slots: int | None = None) -> list[Assignment]:
        """On a difficulty report, add 1..N idle members on fresh directions."""
        difficulty = normalize_difficulty(report.difficulty)
        want = extra_members_for_difficulty(difficulty)
        if want <= 0:
            self.logger.project("diamond_no_reinforce", project_id, reason="low difficulty")
            return []
        idle = self._idle_members(project_id)
        if not idle:
            return []
        want = min(want, self.config.runtime.max_members_per_report, len(idle))
        if available_slots is not None:
            want = min(want, max(0, available_slots))
            if want <= 0:
                self.logger.project("diamond_no_reinforce", project_id, reason="project_member_cap")
                return []

        directions = self._dedupe_directions(
            report.directions or [f"alternate approach to: {report.progress}"]
        )
        start_node = report.node_id or "origin"

        assignments: list[Assignment] = []
        with self.db.connect() as conn:
            if not node_store.fact_exists(conn, project_id, start_node):
                start_node = "origin"
            for member, direction in zip(idle[:want], directions[:want]):
                existing = edge_store.find_similar_open_intent(conn, project_id, [start_node], direction)
                if existing is not None:
                    self.logger.project(
                        "diamond_intent_deduped",
                        project_id,
                        existing_intent=existing.id,
                        source=start_node,
                        direction=direction,
                    )
                    continue
                intent = edge_store.create_intent(conn, project_id, [start_node], direction, "diamond")
                graph_store.add_agent(conn, project_id, member.name, "member", state="active", start_fact_id=start_node)
                graph_store.add_link(conn, project_id, "diamond", member.name, "assign")
                graph_store.add_link(conn, project_id, member.name, f"intent:{intent.id}", "explore")
                assignments.append(Assignment(member=member.name, intent_id=intent.id))
        if not assignments:
            self.logger.project("diamond_no_reinforce", project_id, reason="no_fresh_directions")
            return []
        self.logger.project(
            "diamond_reinforce", project_id, count=len(assignments),
            members=[a.member for a in assignments], difficulty=difficulty,
        )
        return assignments

    def _dedupe_directions(self, directions: list[str]) -> list[str]:
        unique: list[str] = []
        seen: set[str] = set()
        for direction in directions:
            text = (direction or "").strip()
            key = edge_store.normalize_intent_description(text)
            if not key or key in seen:
                continue
            seen.add(key)
            unique.append(text)
        return unique


    def plan_next_intent(self, project_id: str, detail, trigger: str):
        """Create one follow-up intent after a real graph-state checkpoint change."""
        if detail.project.category == "pentest":
            from backend.pentest.store import plan_next
            with self.db.connect() as conn:
                return plan_next(conn, project_id, detail, trigger, max_open=min(2, self.config.runtime.max_members_per_report))
        open_intents = [intent for intent in detail.intents if intent.to is None]
        if open_intents:
            self.logger.project(
                "diamond_reason_noop",
                project_id,
                reason="open_intents_exist",
                trigger=trigger,
            )
            return None
        facts = [fact for fact in detail.facts if fact.id != "goal"]
        source = facts[-1].id if facts else "origin"
        latest = facts[-1].description if facts else ""
        goal = next((fact.description for fact in detail.facts if fact.id == "goal"), "")
        direction = (
            "Continue from the latest confirmed fact and choose the next concrete exploit or analysis step "
            f"toward the goal. Latest fact: {latest[:240]} Goal: {goal[:160]}"
        )
        with self.db.connect() as conn:
            if not node_store.fact_exists(conn, project_id, source):
                source = "origin"
            existing = edge_store.find_similar_open_intent(conn, project_id, [source], direction)
            if existing is not None:
                self.logger.project(
                    "diamond_reason_deduped",
                    project_id,
                    existing_intent=existing.id,
                    source=source,
                    trigger=trigger,
                )
                return None
            intent = edge_store.create_intent(conn, project_id, [source], direction, "diamond")
        self.logger.project(
            "diamond_reason_intent",
            project_id,
            intent=intent.id,
            source=source,
            trigger=trigger,
        )
        return intent



    # ------------------------------------------------------------------
    # Pentest positioning: read a Board, return at most N actions.
    # ------------------------------------------------------------------

    def tick_pentest(self, board, *, ladder=None) -> list:
        """Plan this tick's Pentest actions from a Board.

        Diamond keeps its name and its log prefix.  The CTF entry points
        (assign_initial / decide_reinforcements / plan_next_intent) are
        untouched; this method is only reached for category=pentest projects
        while runtime.diamond_pentest_mode is enabled.
        """

        from backend.pentest.diamond_policy import plan_pentest_actions

        runtime = self.config.runtime
        steps = ladder or (
            (runtime.ladder_help_minutes, "help"),
            (runtime.ladder_upgrade_minutes, "upgrade"),
            (runtime.ladder_park_minutes, "park"),
        )
        actions = plan_pentest_actions(
            board,
            max_actions=runtime.diamond_actions_per_tick,
            ladder=tuple(steps),
            per_project_seats=board.caps.per_project,
        )
        # One line per minute when the board is quiet: the tick runs every few
        # seconds and an unconditional log would bury the project logs during a
        # six-hour run.
        from time import monotonic

        quiet = not actions and (monotonic() - self._pentest_tick_logged_at) < 60
        if not quiet:
            self._pentest_tick_logged_at = monotonic()
            self.logger.project(
                "diamond_pentest_tick",
                "system",
                mode="pentest",
                projects=len(board.projects),
                queue=len(board.queue),
                actions=len(actions),
                kinds=[action.kind for action in actions],
            )
        return actions

    def write_wp(self, project_id: str, wp_dir) -> str:
        """Generate Diamond's final WP from graph state and the relevant execution evidence."""

        evidence_logs = {
            kind: self.logger.read_log(kind, project_id, limit=160)
            for kind in ("project", "tool", "llm", "memory")
        }
        generator = None
        if self.config.diamond.configured and self.config.diamond.api_format != "mock":
            adapter = make_adapter(self.config.diamond, name="diamond")

            def generator(prompt: str) -> str:
                return adapter.chat(
                    [{"role": "user", "content": prompt}],
                    system_prompt=WRITEUP_SYSTEM_PROMPT,
                    temperature=0.1,
                    max_tokens=8192,
                )

        path = write_wp(
            self.db,
            project_id,
            wp_dir,
            generator=generator,
            evidence_logs=evidence_logs,
        )
        self.logger.project("diamond_wp_written", project_id, path=path)
        return path

    def generate_wp_content(self, project_id: str) -> tuple[str, str]:
        """Generate a final writeup while leaving persistence to a fenced caller."""

        evidence_logs = {
            kind: self.logger.read_log(kind, project_id, limit=160)
            for kind in ("project", "tool", "llm", "memory")
        }
        generator = None
        if self.config.diamond.configured and self.config.diamond.api_format != "mock":
            adapter = make_adapter(self.config.diamond, name="diamond")

            def generator(prompt: str) -> str:
                return adapter.chat(
                    [{"role": "user", "content": prompt}],
                    system_prompt=WRITEUP_SYSTEM_PROMPT,
                    temperature=0.1,
                    max_tokens=8192,
                )

        with self.db.connect() as conn:
            row = graph_store.get_project_row(conn, project_id)
            if row and row.get("completion_policy") == "goals":
                from backend.pentest.report import render_report
                return render_report(conn, project_id), ""
        return generate_wp_content(
            self.db,
            project_id,
            generator=generator,
            evidence_logs=evidence_logs,
        )

    def draw_completion(self, project_id: str, connection=None) -> None:
        """Draw the WP -> Diamond -> IPC return lines after flag (Seed.md 流程图).

        Pass ``connection`` to draw inside the caller's transaction so the
        return lines become visible atomically with the triggering state
        change; otherwise a private transaction is used.
        """

        def _draw(conn) -> None:
            row = graph_store.get_project_row(conn, project_id)
            source = "goal" if row and row.get("completion_policy") == "goals" else "flag"
            if not graph_store.link_exists(conn, project_id, source, "wp", "wp"):
                graph_store.add_link(conn, project_id, source, "wp", "wp")
            if not graph_store.link_exists(conn, project_id, "wp", "diamond", "wp"):
                graph_store.add_link(conn, project_id, "wp", "diamond", "wp")
            if not graph_store.link_exists(conn, project_id, "diamond", "ipc", "return"):
                graph_store.add_link(conn, project_id, "diamond", "ipc", "return")
            graph_store.set_agent_state(conn, project_id, "diamond", "done")
            for name in graph_store.active_member_names(conn, project_id):
                graph_store.set_agent_state(conn, project_id, name, "done")

        if connection is not None:
            _draw(connection)
            return
        with self.db.connect() as conn:
            _draw(conn)
