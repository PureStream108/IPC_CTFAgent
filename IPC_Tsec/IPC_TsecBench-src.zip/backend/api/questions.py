from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.api.deps import get_state
from backend.competition.store import CompetitionConflict
from backend.ops.questions import QuestionStore
from backend.ops.store import WorkflowSessionConflict

router = APIRouter(prefix="/questions", tags=["questions"])


class Answer(BaseModel):
    session_id: str
    value: str = Field(min_length=1, max_length=16384)


class Dismiss(BaseModel):
    session_id: str



_GET_STATE_DEPENDENCY = Depends(get_state)

@router.get("")
def pending_questions(session_id: str, state=_GET_STATE_DEPENDENCY):
    return {"questions": QuestionStore(state).list(session_id)}


@router.post("/{question_id}/dismiss")
def dismiss_question(question_id: str, body: Dismiss, state=_GET_STATE_DEPENDENCY):
    try:
        return QuestionStore(state).dismiss(question_id, body.session_id)
    except KeyError as exc:
        raise HTTPException(404, "Question not found") from exc


@router.post("/{question_id}/answer")
def answer_question(question_id: str, body: Answer, state=_GET_STATE_DEPENDENCY):
    try:
        return QuestionStore(state).answer(question_id, body.session_id, body.value)
    except KeyError as exc:
        raise HTTPException(404, "Question not found") from exc
    except CompetitionConflict as exc:
        raise HTTPException(409, str(exc)) from exc
    except WorkflowSessionConflict as exc:
        raise HTTPException(409, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
