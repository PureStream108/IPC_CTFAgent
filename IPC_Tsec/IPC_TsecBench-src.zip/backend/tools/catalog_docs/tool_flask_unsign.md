# flask-unsign

解码、校验和签名 Flask session cookie，并可用字典测试弱 secret key。

## 用途与适用场景

发现 Flask session cookie、怀疑 secret key 较弱，或需要修改 session 内容验证越权时使用。

## 版本检查

```bash
flask-unsign --help | head -20
```

## 命令、导入与镜像路径

- 常用入口：`flask-unsign`
- 镜像路径：`/usr/local/bin/flask-unsign`

## 常用工作流

先 `--decode --cookie` 查看结构；已知 secret 时用 `--sign` 生成新 cookie、`--unsign` 校验；字典攻击只对授权目标使用，先小字典再逐步扩大并控制速率。

## 可执行示例

```bash
flask-unsign --decode --cookie 'eyJ...' && flask-unsign --unsign --cookie 'eyJ...' --wordlist /workspace/wordlists/rockyou.txt --no-literal-eval
```

## 输出解释

decode 输出 JSON 结构；unsign 成功时打印 secret；sign 输出新 cookie。注意 Flask 的 itsdangerous 版本和盐值会影响结果。

## 常见错误与限制

没有 secret 时只能爆破，rockyou 很大且可能超时；优先使用题目线索中的小字典。不要对生产系统进行未授权爆破。

## 关联条目

- [flask-session-cookie](/memory/catalog/tool_flask_session_cookie/document)
- [常用字典](/memory/catalog/core_wordlists/document)
- [Requests / Flask / PyJWT / jwcrypto / Jinja2](/memory/catalog/lib_web_python/document)

## 官方参考

- [https://github.com/Paradoxis/Flask-Unsign](https://github.com/Paradoxis/Flask-Unsign)
