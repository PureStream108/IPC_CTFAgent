from __future__ import annotations

from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
from pathlib import Path
from threading import BoundedSemaphore
from urllib.parse import urlsplit


def stage_challenges(adapter_factory: Callable, challenges: list, destination: Path, *, workers: int = 4) -> dict[str, list[Path]]:
    if not 1 <= workers <= 16:
        raise ValueError("download workers must be between 1 and 16")
    ids = [c.external_id for c in challenges]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate challenge identity in platform response")
    destination.mkdir(parents=True, exist_ok=True)
    origins = {
        c.external_id: sorted({urlsplit(url).netloc.lower() for url in c.attachment_urls} or {"platform"})
        for c in challenges
    }
    gates = {origin: BoundedSemaphore(2) for group in origins.values() for origin in group}

    def download(item):
        index, challenge = item
        directory = destination / str(index)
        adapter = adapter_factory()
        with ExitStack() as stack:
            for origin in origins[challenge.external_id]:
                stack.enter_context(gates[origin])
            files = adapter.download_attachments(challenge, directory)
        for file in files:
            if not file.resolve().is_relative_to(directory.resolve()) or not file.is_file():
                raise ValueError("adapter returned a file outside its staging directory")
        return challenge.external_id, files

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ipc-download") as pool:
        return dict(pool.map(download, enumerate(challenges)))
