AGENT_SCHEMA = (
    """CREATE TABLE IF NOT EXISTS agent_sessions (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL CHECK (kind IN ('ops','competition','project')),
        task_key TEXT NOT NULL,
        parent_session_id TEXT REFERENCES agent_sessions(id),
        lineage_reason TEXT CHECK (lineage_reason IS NULL OR lineage_reason IN
          ('fork','resume','redirect','member_handoff','model_switch','helper')),
        provider_session_id TEXT,
        provider_session_state TEXT NOT NULL DEFAULT 'unknown'
          CHECK (provider_session_state IN ('unknown','native','degraded','unsupported')),
        model_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
        state TEXT NOT NULL DEFAULT 'active'
          CHECK (state IN ('active','idle','finished','failed','superseded')),
        next_sequence BIGINT NOT NULL DEFAULT 1,
        token_budget JSONB NOT NULL DEFAULT '{}'::jsonb,
        checkpoint JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )""",
    """CREATE UNIQUE INDEX IF NOT EXISTS uq_agent_session_active_task
       ON agent_sessions(task_key)
       WHERE state='active' AND parent_session_id IS NULL""",
    "CREATE INDEX IF NOT EXISTS ix_agent_sessions_task ON agent_sessions(task_key,created_at)",
    """CREATE TABLE IF NOT EXISTS agent_session_writers (
        session_id TEXT PRIMARY KEY REFERENCES agent_sessions(id) ON DELETE CASCADE,
        worker_kind TEXT NOT NULL,
        owner TEXT NOT NULL,
        epoch BIGINT NOT NULL DEFAULT 1,
        lease_expires_at TIMESTAMPTZ NOT NULL,
        last_renewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )""",
    """CREATE TABLE IF NOT EXISTS agent_turns (
        session_id TEXT NOT NULL REFERENCES agent_sessions(id) ON DELETE CASCADE,
        turn INTEGER NOT NULL,
        owner TEXT NOT NULL,
        epoch BIGINT NOT NULL DEFAULT 0,
        status TEXT NOT NULL CHECK (status IN
          ('running','completed','cancelled','failed','truncated')),
        prompt_tokens INTEGER,
        output_tokens INTEGER,
        reasoning_tokens INTEGER,
        started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        finished_at TIMESTAMPTZ,
        PRIMARY KEY (session_id, turn)
    )""",
    """CREATE TABLE IF NOT EXISTS agent_events (
        session_id TEXT NOT NULL REFERENCES agent_sessions(id) ON DELETE CASCADE,
        sequence BIGINT NOT NULL,
        event_id BIGSERIAL,
        turn INTEGER,
        event_key TEXT NOT NULL,
        kind TEXT NOT NULL CHECK (kind IN
          ('user_message','provider_messages','reasoning','tool_call','tool_result',
           'status','error','handoff','loop_detected',
           -- Transitional: the competition runtime still records compaction as
           -- an event. Phase 2 moves it to agent_compactions and these two
           -- kinds leave the contract.
           'context_compacted','compression_failed')),
        payload JSONB NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        PRIMARY KEY (session_id, sequence),
        UNIQUE (session_id, event_key)
    )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS uq_agent_event_id ON agent_events(event_id)",
    """CREATE TABLE IF NOT EXISTS agent_compactions (
        compaction_id BIGSERIAL PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES agent_sessions(id) ON DELETE CASCADE,
        up_to_sequence BIGINT NOT NULL,
        summary JSONB NOT NULL,
        token_estimate INTEGER,
        generated_by JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )""",
    """CREATE INDEX IF NOT EXISTS ix_agent_compactions_session
       ON agent_compactions(session_id, up_to_sequence DESC)""",
    """CREATE TABLE IF NOT EXISTS agent_jobs (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES agent_sessions(id) ON DELETE CASCADE,
        project_id TEXT,
        member TEXT,
        intent_id TEXT,
        kind TEXT NOT NULL,
        command TEXT NOT NULL,
        state TEXT NOT NULL DEFAULT 'running'
          CHECK (state IN ('running','exited','cancelled','lost')),
        exit_code INTEGER,
        stdout_artifact TEXT,
        stderr_artifact TEXT,
        workdir TEXT,
        pid INTEGER,
        stdout_offset BIGINT NOT NULL DEFAULT 0,
        stderr_offset BIGINT NOT NULL DEFAULT 0,
        digest_state TEXT NOT NULL DEFAULT 'none',
        digest_json JSONB,
        digest_at TIMESTAMPTZ,
        delivered_at TIMESTAMPTZ,
        digest_attempts INTEGER NOT NULL DEFAULT 0,
        started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        last_progress_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        finished_at TIMESTAMPTZ
    )""",
    """CREATE INDEX IF NOT EXISTS ix_agent_jobs_session
       ON agent_jobs(session_id, started_at DESC)""",
    """CREATE INDEX IF NOT EXISTS ix_agent_jobs_running
       ON agent_jobs(session_id) WHERE state='running'""",
    """CREATE INDEX IF NOT EXISTS ix_agent_jobs_curator
       ON agent_jobs(project_id,digest_state,finished_at)""",
    """CREATE INDEX IF NOT EXISTS ix_agent_jobs_member_digest
       ON agent_jobs(project_id,member,digest_state,finished_at)""",
    "DROP VIEW IF EXISTS agent_session_health",
    """CREATE OR REPLACE VIEW agent_session_health AS
       SELECT s.id AS session_id,
              s.kind,
              s.task_key,
              s.state,
              w.owner,
              w.epoch,
              w.worker_kind,
              w.last_renewed_at,
              -- The worker's own proof of life, which is what separates "the
              -- coordinator is ticking" from "a worker is turning".
              (w.lease_expires_at > now()) AS worker_live,
              w.lease_expires_at AS worker_lease_expires_at,
              e.last_event_at,
              e.last_event_kind,
              -- Counts are coalesced to 0 rather than left NULL by the outer
              -- join: "no events yet" is a number, and leaving it NULL pushes
              -- the same COALESCE into every consumer.
              COALESCE(e.event_count, 0) AS event_count,
              t.current_turn,
              t.current_turn_started_at,
              t.last_finished_turn_at,
              t.turn_status,
              COALESCE(j.running_jobs, 0) AS running_jobs,
              j.last_job_progress_at,
              -- Quiet time is measured from the most recent sign of progress of
              -- any kind. A long provider turn and a long tool both count as
              -- progress; only genuine silence accumulates here.
              GREATEST(
                COALESCE(e.last_progress_event_at, s.created_at),
                COALESCE(t.current_turn_started_at, s.created_at),
                COALESCE(t.last_finished_turn_at, s.created_at),
                COALESCE(j.last_job_progress_at, s.created_at)
              ) AS last_progress_at,
              EXTRACT(EPOCH FROM now() - GREATEST(
                COALESCE(e.last_progress_event_at, s.created_at),
                COALESCE(t.current_turn_started_at, s.created_at),
                COALESCE(t.last_finished_turn_at, s.created_at),
                COALESCE(j.last_job_progress_at, s.created_at)
              ))::bigint AS quiet_seconds
       FROM agent_sessions s
       LEFT JOIN agent_session_writers w ON w.session_id = s.id
       LEFT JOIN (
         SELECT session_id,
                max(created_at) AS last_event_at,
                max(created_at) FILTER (WHERE kind IN ('tool_call','tool_result','context_compacted')
                    OR (kind='status' AND payload->>'status' IN
                        ('provider.started','provider.first_content','provider.progress','provider.completed',
                         'compaction.started','compaction.completed'))) AS last_progress_event_at,
                count(*) AS event_count,
                (array_agg(kind ORDER BY sequence DESC))[1] AS last_event_kind
         FROM agent_events GROUP BY session_id
       ) e ON e.session_id = s.id
       LEFT JOIN (
         SELECT session_id,
                max(turn) AS current_turn,
                max(started_at) FILTER (WHERE status='running') AS current_turn_started_at,
                max(finished_at) AS last_finished_turn_at,
                (array_agg(status ORDER BY turn DESC))[1] AS turn_status
         FROM agent_turns GROUP BY session_id
       ) t ON t.session_id = s.id
       LEFT JOIN (
         SELECT session_id,
                count(*) FILTER (WHERE state='running') AS running_jobs,
                max(last_progress_at) AS last_job_progress_at
         FROM agent_jobs GROUP BY session_id
       ) j ON j.session_id = s.id""",
    "ALTER TABLE IF EXISTS sessions ADD COLUMN IF NOT EXISTS agent_session_id TEXT",
    """DO $$ BEGIN
       IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='sessions_agent_session_fk') THEN
           ALTER TABLE sessions ADD CONSTRAINT sessions_agent_session_fk
             FOREIGN KEY (agent_session_id) REFERENCES agent_sessions(id) ON DELETE SET NULL;
       END IF;
       END $$""",
)
