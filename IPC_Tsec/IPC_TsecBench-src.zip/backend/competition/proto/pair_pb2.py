from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC,
    6,
    33,
    5,
    '',
    'backend/competition/proto/pair.proto'
)

_sym_db = _symbol_database.Default()




DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n$backend/competition/proto/pair.proto\x12\x12ipc.competition.v1\"\xe0\x02\n\x08\x45nvelope\x12\x18\n\x10protocol_version\x18\x01 \x01(\r\x12\x0e\n\x06run_id\x18\x02 \x01(\t\x12\x14\n\x0c\x63hallenge_id\x18\x03 \x01(\t\x12\x18\n\x10sender_member_id\x18\x04 \x01(\t\x12\x1a\n\x12receiver_member_id\x18\x05 \x01(\t\x12\x19\n\x11sender_session_id\x18\x06 \x01(\t\x12\x1b\n\x13receiver_session_id\x18\x07 \x01(\t\x12\x12\n\nrequest_id\x18\x08 \x01(\t\x12\x16\n\x0e\x63orrelation_id\x18\t \x01(\t\x12\x10\n\x08sequence\x18\n \x01(\x04\x12\x13\n\x0blease_epoch\x18\x0b \x01(\x04\x12\x12\n\ncreated_at\x18\x0c \x01(\t\x12\x13\n\x0b\x64\x65\x61\x64line_at\x18\r \x01(\t\x12\x14\n\x0cmessage_type\x18\x0e \x01(\t\x12\x14\n\x0cpayload_json\x18\x0f \x01(\x0c\"B\n\x06Result\x12\x0e\n\x06status\x18\x01 \x01(\t\x12\x12\n\nrequest_id\x18\x02 \x01(\t\x12\x14\n\x0cpayload_json\x18\x03 \x01(\x0c\x32H\n\x04Pair\x12@\n\x04\x43\x61ll\x12\x1c.ipc.competition.v1.Envelope\x1a\x1a.ipc.competition.v1.Resultb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'backend.competition.proto.pair_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
  DESCRIPTOR._loaded_options = None
  _globals['_ENVELOPE']._serialized_start=61
  _globals['_ENVELOPE']._serialized_end=413
  _globals['_RESULT']._serialized_start=415
  _globals['_RESULT']._serialized_end=481
  _globals['_PAIR']._serialized_start=483
  _globals['_PAIR']._serialized_end=555
