from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import shlex
import tarfile
import threading
import time
import uuid
from contextlib import suppress
from pathlib import Path, PurePosixPath

from backend.sandbox.docker_manager import _load_docker_sdk
from backend.sandbox.errors import (
    DockerConfigurationError,
    DockerImageError,
    SandboxStartupError,
    classify_docker_startup_error,
)
from backend.sandbox.output import (
    DEFAULT_OUTPUT_BYTES,
    OUTPUT_FINALIZER,
    OUTPUT_PAGE_READER,
)
from backend.sandbox.sandbox import ExecResult
from backend.sandbox.webui_proxy import webui_proxy_manager

_recovery_logger = logging.getLogger(__name__)

WORKSPACE = "/workspace"
# One docker API client is shared by every caller of this TaskSandbox, and
# exec_run is a blocking HTTP round trip on a connection pool that is not
# documented as thread-safe. Bounding the number of concurrent execs keeps a
# burst of Members from piling onto the same handle while still allowing real
# concurrency; the alternative (one client per thread) would re-resolve the
# container on every call and would change what tests inject as _container.
MAX_CONCURRENT_EXECS = 8
# Container-wide settings applied to every task container we create.
DEFAULT_CONTAINER_ENV: dict[str, str] = {"MALLOC_ARENA_MAX": "2"}
ATTACHMENTS_DIR = f"{WORKSPACE}/attachments"
SHARED_DIR = f"{WORKSPACE}/shared"
JOBS_DIR = f"{WORKSPACE}/.ipc/jobs"


def _safe_segment(value: str) -> str:
    import re

    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._")
    return text or "workspace"


def job_dir(job_id: str) -> str:
    return f"{JOBS_DIR}/{_safe_segment(job_id)}"




def job_launch_script(directory: str, command: str, workdir: str) -> str:
    """Shell that starts ``command`` detached and records its exit status.

    Two details carry the durability:

    * ``set -m`` enables job control, which puts the background job in its own
      process group.  That is what lets ``job_cancel_script`` kill the whole
      tree with one negative PID instead of orphaning grandchildren that still
      hold the output files open.  ``setsid`` would do the same but is not
      present in every shell the tests and dev sandboxes use, and a silent
      ``command not found`` there means the job never starts at all.
    * The supervisor writes ``status`` only after the real command exits, so a
      missing ``status`` file means "did not finish", never "succeeded".

    Written as separate statements rather than one ``&&`` chain on purpose:
    ``&`` binds more loosely than ``&&``, so a single chain ending in ``&``
    backgrounds the *whole* chain - including the ``mkdir`` - and the following
    write of the pid file then races a directory that does not exist yet.
    """
    quoted = shlex.quote(directory)
    supervisor = (
        f"bash -lc {shlex.quote(command)} "
        f"> {quoted}/stdout 2> {quoted}/stderr < /dev/null; "
        f"printf '%s' \"$?\" > {quoted}/status"
    )
    return "\n".join((
        "set -e",
        f"mkdir -p {quoted}",
        f"cd {shlex.quote(workdir)}",
        "set -m",
        f"nohup bash -c {shlex.quote(supervisor)} >/dev/null 2>&1 < /dev/null &",
        "child=$!",
        f"printf '%s' \"$child\" > {quoted}/pid",
        (f"(sed 's/.*) //' /proc/$child/stat 2>/dev/null | awk '{{print $20}}' "
        f"|| true) > {quoted}/starttime"),
        f"cat {quoted}/pid",
    ))


def job_probe_script(directory: str) -> str:
    """Shell that reports a job's pid, recorded status and liveness.

    Liveness requires both that the pid exists *and* that its start time still
    matches what was recorded at launch. Without the second check a recycled
    pid - routine after a container restart, where pids begin again from low
    numbers - makes a long-dead job look like it is still running.
    """
    quoted = shlex.quote(directory)
    return (
        f"pid=$(cat {quoted}/pid 2>/dev/null || true); "
        f"status=$(cat {quoted}/status 2>/dev/null || true); "
        f"want=$(cat {quoted}/starttime 2>/dev/null || true); "
        f"alive=no; "
        f'if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then alive=yes; fi; '
        f"have=$(sed 's/.*) //' /proc/$pid/stat 2>/dev/null | awk '{{print $20}}' || true); "
        f'if [ "$alive" = yes ] && [ -n "$want" ] && [ -n "$have" ] '
        f'&& [ "$want" != "$have" ]; then alive=no; fi; '
        f"out=$(wc -c < {quoted}/stdout 2>/dev/null || echo 0); "
        f"err=$(wc -c < {quoted}/stderr 2>/dev/null || echo 0); "
        f"printf 'pid=%s status=%s alive=%s stdout=%s stderr=%s' "
        f'"$pid" "$status" "$alive" "$out" "$err"'
    )


def job_cancel_script(directory: str) -> str:
    """Shell that kills a job's whole process group, then the leader.

    Same reasoning as the exec timeout path (commit 3612261): killing only the
    leader leaves grandchildren alive holding the output files open. The
    negative PID targets the process group that ``set -m`` created in
    ``job_launch_script`` for exactly this.
    """
    quoted = shlex.quote(directory)
    return (
        f"pid=$(cat {quoted}/pid 2>/dev/null || true); "
        f'if [ -z "$pid" ]; then exit 1; fi; '
        f'kill -TERM -"$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true; '
        f"sleep 2; "
        f'kill -KILL -"$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true; '
        f"exit 0"
    )


def parse_job_probe(output: str) -> dict:
    """Turn ``job_probe_script`` output into a state dict.

    ``lost`` is deliberate: a pid that is gone with no recorded status means
    the container restarted or something outside killed the process, and
    reporting that as ``exited 0`` would hand the model a fabricated success.
    """
    fields = dict(
        item.split("=", 1) for item in (output or "").split() if "=" in item
    )
    status = fields.get("status", "").strip()
    alive = fields.get("alive") == "yes"
    if status:
        state = "exited"
    elif alive:
        state = "running"
    else:
        state = "lost"
    return {
        "state": state,
        "exit_code": int(status) if status.lstrip("-").isdigit() else None,
        "pid": int(fields["pid"]) if fields.get("pid", "").isdigit() else None,
        "stdout_bytes": int(fields.get("stdout", "0") or 0),
        "stderr_bytes": int(fields.get("stderr", "0") or 0),
    }


def task_container_name(project_id: str) -> str:
    return f"ipc-task-{_safe_segment(project_id)}"


def member_workdir(member: str) -> str:
    return SHARED_DIR


class TaskSandbox:

    def __init__(
        self,
        project_id: str,
        image: str,
        env: dict[str, str] | None = None,
        network: bool = True,
        attachments_dir: str | Path | None = None,
        mem_limit: str | None = None,
        pids_limit: int | None = None,
    ):
        self.project_id = project_id
        self.image = image
        # MALLOC_ARENA_MAX keeps glibc from reserving one 64MB arena per
        # thread; with several Python workers inside one task the default arena
        # count is the difference between 300MB and 900MB RSS.
        # Execs pass environment explicitly, so the value has to live in
        # self.env rather than only in the container's creation environment.
        self.env = {**DEFAULT_CONTAINER_ENV, **(env or {})}
        self.network = network
        self.mem_limit = mem_limit
        self.pids_limit = pids_limit
        self.attachments_dir = Path(attachments_dir) if attachments_dir is not None else None
        self._container = None
        self._client = None
        self._sdk = None
        self._preflight_complete = False
        self._container_name = task_container_name(project_id)
        self._volume_name = f"{self._container_name}-workspace"
        self._shared_network: str | None = None
        self._lock = threading.RLock()
        self._member_dirs: set[str] = set()
        self._exec_slots = threading.BoundedSemaphore(MAX_CONCURRENT_EXECS)

    def _docker(self):
        if self._client is None:
            docker = _load_docker_sdk()
            try:
                client = docker.from_env()
            except Exception as exc:
                raise classify_docker_startup_error(
                    exc,
                    "configure Docker client",
                ) from exc
            self._sdk = docker
            self._client = client
        if not self._preflight_complete:
            ping = getattr(self._client, "ping", None)
            if callable(ping):
                try:
                    ping()
                except Exception as exc:
                    raise classify_docker_startup_error(
                        exc,
                        "contact Docker daemon",
                    ) from exc
            self._preflight_complete = True
        return self._client

    def preflight(self) -> None:
        """Validate Docker configuration/socket/daemon before solver reasoning."""

        self._docker()

    def _shared_network_name(self) -> str | None:
        configured = os.environ.get("IPC_MEMBER_DOCKER_NETWORK", "").strip()
        if configured:
            return configured
        hostname = os.environ.get("HOSTNAME", "").strip()
        if not hostname:
            return None
        try:
            current = self._docker().containers.get(hostname)
        except Exception:
            _recovery_logger.debug('Error handled in _shared_network_name', exc_info=True)
            return None
        networks = current.attrs.get("NetworkSettings", {}).get("Networks", {})
        if not networks:
            return None
        for name in networks:
            if name != "bridge":
                return name
        return next(iter(networks), None)


    def start(self) -> None:
        with self._lock:
            if self._container is not None:
                return
            client = self._docker()
            from docker.errors import ImageNotFound, NotFound

            created = False
            try:
                try:
                    container = client.containers.get(self._container_name)
                    container.reload()
                    mounts = getattr(container, "attrs", {}).get("Mounts")
                    if mounts is not None and not any(m.get("Destination") == WORKSPACE for m in mounts):
                        raise DockerConfigurationError(
                            "legacy task container has no persistent workspace; export /workspace before recreating it",
                            operation="validate workspace persistence",
                        )
                    if getattr(container, "status", "running") != "running":
                        container.start()
                except NotFound:
                    run_kwargs = {
                        "image": self.image,
                        "command": ["sleep", "infinity"],
                        "detach": True,
                        "name": self._container_name,
                        "working_dir": "/",
                        "extra_hosts": {"host.docker.internal": "host-gateway"},
                        "volumes": {self._volume_name: {"bind": WORKSPACE, "mode": "rw"}},
                        "environment": dict(self.env) or None,
                    }
                    if self.mem_limit:
                        run_kwargs["mem_limit"] = self.mem_limit
                    if self.pids_limit:
                        run_kwargs["pids_limit"] = int(self.pids_limit)
                    if self.network:
                        self._shared_network = self._shared_network_name()
                        if self._shared_network:
                            run_kwargs["network"] = self._shared_network
                        else:
                            run_kwargs["network_mode"] = "bridge"
                    else:
                        run_kwargs["network_mode"] = "none"
                    try:
                        container = client.containers.run(**run_kwargs)
                        created = True
                    except ImageNotFound as exc:
                        raise DockerImageError(
                            f"task image '{self.image}' is unavailable; "
                            "build the ipc-task-image service first",
                            operation="create task container",
                        ) from exc
                    except Exception as exc:
                        raise classify_docker_startup_error(
                            exc,
                            "create task container",
                        ) from exc
                except Exception as exc:
                    if isinstance(exc, SandboxStartupError):
                        raise
                    raise classify_docker_startup_error(
                        exc,
                        "inspect or start task container",
                    ) from exc
                else:
                    networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
                    self._shared_network = next(
                        (name for name in networks if name != "bridge"), None
                    )

                self._container = container
                self._init_workspace(container)
                self._copy_attachments()
            except Exception as exc:
                with suppress(Exception):
                    if created and "container" in locals():
                        container.remove(force=True)
                self._container = None
                if isinstance(exc, SandboxStartupError):
                    raise
                raise classify_docker_startup_error(
                    exc,
                    "initialize task container",
                ) from exc

    def _init_workspace(self, container) -> None:
        setup = (
            f"mkdir -p {shlex.quote(ATTACHMENTS_DIR)} {shlex.quote(SHARED_DIR)} "
            f"&& if [ -d /opt/ipc-tools/tools ] && [ ! -e {WORKSPACE}/tools ]; then "
            f"ln -s /opt/ipc-tools/tools {WORKSPACE}/tools; fi "
            f"&& if [ -d /opt/ipc-tools/wordlists ] && [ ! -e {WORKSPACE}/wordlists ]; then "
            f"ln -s /opt/ipc-tools/wordlists {WORKSPACE}/wordlists; fi "
            f"&& if [ -f /tools.txt ]; then cp /tools.txt {WORKSPACE}/tools.txt; fi"
        )
        res = container.exec_run(["bash", "-lc", setup], workdir="/")
        if res.exit_code not in (0, None):
            detail = self._decode_output(res.output)
            raise DockerConfigurationError(
                f"failed to initialize task workspace: {detail.strip()}",
                operation="initialize task container",
            )

    @staticmethod
    def _decode_output(output) -> str:
        if isinstance(output, tuple):
            out, err = output
            return b"\n".join(part for part in (out, err) if part).decode(errors="replace")
        if isinstance(output, bytes):
            return output.decode(errors="replace")
        return str(output)

    def _copy_attachments(self) -> None:
        if self._container is None or self.attachments_dir is None:
            return
        src = self.attachments_dir
        if not src.exists() or not src.is_dir():
            return
        stream = io.BytesIO()
        with tarfile.open(fileobj=stream, mode="w") as tar:
            for path in sorted(src.rglob("*"), key=lambda p: str(p.relative_to(src))):
                rel = path.relative_to(src)
                arcname = PurePosixPath(*rel.parts).as_posix()
                tar.add(path, arcname=arcname, recursive=False)
        stream.seek(0)
        self._container.put_archive(ATTACHMENTS_DIR, stream.getvalue())

    def stop(self) -> None:
        webui_proxy_manager.close_project(self.project_id)
        with self._lock:
            if self._container is not None:
                with suppress(Exception):
                    self._container.remove(force=True)
                self._container = None
            self._member_dirs.clear()


    def member_view(self, member: str) -> MemberSandbox:
        workdir = member_workdir(member)
        with self._lock:
            if workdir not in self._member_dirs:
                if self._container is None:
                    self.start()
                self._raw_exec(f"mkdir -p {shlex.quote(workdir)}", workdir="/", timeout=10)
                self._member_dirs.add(workdir)
        return MemberSandbox(self, member, workdir)


    def exec(self, command: str, workdir: str, timeout: int = 60) -> ExecResult:
        if self._container is None:
            self.start()
        return self._raw_exec(command, workdir=workdir, timeout=timeout)

    def _raw_exec(self, command: str, workdir: str, timeout: int = 60) -> ExecResult:
        wrapped = f"timeout -k 5s {timeout}s bash -lc {shlex.quote(command)}"
        env = self.env or None
        # Snapshot the handle: start() may replace ``_container`` from another
        # thread, and a torn read would exec into a container being removed.
        container = self._container
        if container is None:
            raise RuntimeError("task container is not running")
        with self._exec_slots:
            res = container.exec_run(
                ["bash", "-lc", wrapped], workdir=workdir, demux=True, environment=env
            )
        out, err = res.output if isinstance(res.output, tuple) else (res.output, None)
        stdout = out.decode(errors="replace") if out else ""
        stderr = err.decode(errors="replace") if err else ""
        timed_out = res.exit_code in (124, 137)
        return ExecResult(res.exit_code if res.exit_code is not None else -1, stdout, stderr, timed_out)

    def exec_bounded(self, command: str, workdir: str, timeout: int = 60) -> ExecResult:
        if self._container is None:
            self.start()
        identifier = uuid.uuid4().hex
        directory = f"{SHARED_DIR}/.ipc-output"
        stdout, stderr = (f"{directory}/{identifier}.{stream}" for stream in ("stdout", "stderr"))
        limit = max(1024, int(getattr(self, "output_limit", DEFAULT_OUTPUT_BYTES)))
        script = "\n".join([
            f"mkdir -p {shlex.quote(directory)}",
            f"timeout -k 5s {timeout}s bash -lc {shlex.quote(command)} >{shlex.quote(stdout)} 2>{shlex.quote(stderr)}",
            "ipc_output_status=$?",
            (f"python3 -c {shlex.quote(OUTPUT_FINALIZER)} {shlex.quote(stdout)} {shlex.quote(stderr)} "
             f'"$ipc_output_status" {limit // 2}'),
        ])
        started = time.monotonic()
        envelope = self._raw_exec(script, workdir=workdir, timeout=timeout + 15)
        if not envelope.ok:
            return envelope
        try:
            payload = json.loads(envelope.stdout)
            code = int(payload["exit_code"])
            return ExecResult(code, payload["stdout"], payload["stderr"], code in (124, 137),
                              payload["artifacts"], round(time.monotonic() - started, 6))
        except (ValueError, KeyError, TypeError):
            raise RuntimeError("sandbox output finalizer returned an invalid envelope") from None

    # --- async surface -------------------------------------------------
    # exec_run is a blocking HTTP round trip, so a coroutine that calls it
    # directly stalls the whole event loop: API requests, WebSocket pushes and
    # every other Member's model stream wait behind it. These wrappers move the
    # call onto a worker thread and exist so each call site does not reinvent
    # the hop (and so one test covers the behaviour instead of one per site).
    async def aexec(self, command: str, workdir: str, timeout: int = 60) -> ExecResult:
        return await asyncio.to_thread(self.exec, command, workdir=workdir, timeout=timeout)

    async def aexec_bounded(self, command: str, workdir: str, timeout: int = 60) -> ExecResult:
        return await asyncio.to_thread(
            self.exec_bounded, command, workdir=workdir, timeout=timeout
        )

    async def aread_page(
        self, path: str, *, workdir: str, offset: int = 0, limit: int = 8192
    ) -> dict:
        return await asyncio.to_thread(
            self.read_page, path, workdir=workdir, offset=offset, limit=limit
        )

    async def aexec_detached(self, job_id: str, command: str, workdir: str) -> int:
        return await asyncio.to_thread(self.exec_detached, job_id, command, workdir)

    async def ajob_state(self, job_id: str) -> dict:
        return await asyncio.to_thread(self.job_state, job_id)

    async def ajob_output(
        self, job_id: str, stream: str = "stdout", *, offset: int = 0,
        limit: int = 32_768,
    ) -> tuple[str, int]:
        return await asyncio.to_thread(
            self.job_output, job_id, stream, offset=offset, limit=limit
        )

    async def ajob_cancel(self, job_id: str) -> bool:
        return await asyncio.to_thread(self.job_cancel, job_id)

    async def awrite_file(self, workdir: str, rel_path: str, content: str) -> None:
        await asyncio.to_thread(self.write_file, workdir, rel_path, content)


    def read_page(self, path: str, *, workdir: str, offset: int = 0, limit: int = 8192) -> dict:
        target = str(PurePosixPath(workdir) / path) if not PurePosixPath(path).is_absolute() else path
        result = self._raw_exec(f"python3 -c {shlex.quote(OUTPUT_PAGE_READER)} {shlex.quote(target)} {int(offset)} {int(limit)}",
                                workdir=workdir, timeout=10)
        if not result.ok:
            raise ValueError("artifact is unavailable or outside this workspace")
        return json.loads(result.stdout)

    def exec_detached(self, job_id: str, command: str, workdir: str) -> int:
        """Start ``command`` with no timeout and return its process-group PID.

        No ``timeout`` wrapper: removing the 60s ceiling is the point. The
        durable handle is the PID and output files under ``job_dir``, not a
        docker exec id, because an exec id dies with a container restart while
        the workspace volume survives it.
        """
        if self._container is None:
            self.start()
        result = self._raw_exec(
            job_launch_script(job_dir(job_id), command, workdir),
            workdir=workdir,
            timeout=20,
        )
        if not result.ok:
            raise RuntimeError(
                f"failed to start detached job: {(result.stderr or result.stdout).strip()}"
            )
        try:
            return int(result.stdout.strip().splitlines()[-1])
        except (ValueError, IndexError) as exc:
            raise RuntimeError(
                f"detached job reported no pid: {result.stdout.strip()!r}"
            ) from exc

    def job_state(self, job_id: str) -> dict:
        """Report a detached job's liveness and exit status from its files."""
        result = self._raw_exec(
            job_probe_script(job_dir(job_id)), workdir=WORKSPACE, timeout=15
        )
        return parse_job_probe(result.stdout)

    def job_output(
        self, job_id: str, stream: str = "stdout", *, offset: int = 0,
        limit: int = 32_768,
    ) -> tuple[str, int]:
        """Read a job's output incrementally; returns ``(text, next_offset)``.

        Byte offsets rather than line counts so a partially written line cannot
        shift the cursor and duplicate output on the next poll.
        """
        if stream not in {"stdout", "stderr"}:
            raise ValueError("stream must be stdout or stderr")
        path = f"{job_dir(job_id)}/{stream}"
        quoted = shlex.quote(path)
        result = self._raw_exec(
            f"tail -c +{max(0, offset) + 1} {quoted} 2>/dev/null | head -c {max(1, limit)}",
            workdir=WORKSPACE,
            timeout=20,
        )
        text = result.stdout or ""
        return text, max(0, offset) + len(text.encode("utf-8", errors="replace"))

    def job_cancel(self, job_id: str) -> bool:
        """Kill a job's whole process group; see ``job_cancel_script``."""
        result = self._raw_exec(
            job_cancel_script(job_dir(job_id)), workdir=WORKSPACE, timeout=20
        )
        return result.ok


    def write_file(self, workdir: str, rel_path: str, content: str) -> None:
        if self._container is None:
            self.start()
        path = str(PurePosixPath(workdir) / rel_path)
        data = content.encode("utf-8")
        stream = io.BytesIO()
        with tarfile.open(fileobj=stream, mode="w") as tar:
            info = tarfile.TarInfo(name=PurePosixPath(rel_path).name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        stream.seek(0)
        parent = str(PurePosixPath(path).parent)
        self._raw_exec(f"mkdir -p {shlex.quote(parent)}", workdir="/", timeout=10)
        self._container.put_archive(parent, stream.getvalue())

    def read_file(self, workdir: str, rel_path: str) -> str | None:
        res = self.exec(f"cat {shlex.quote(rel_path)}", workdir=workdir, timeout=15)
        if not res.ok:
            return None
        return res.stdout


    def proxy_target_host(self) -> str:
        if self._container is None:
            raise RuntimeError("task container is not running")
        if self._shared_network:
            return self._container_name
        networks = self._container.attrs.get("NetworkSettings", {}).get("Networks", {})
        for data in networks.values():
            ip = data.get("IPAddress", "")
            if ip:
                return ip
        return self._container_name


class MemberSandbox:
    """A per-Member view onto a shared TaskSandbox.

    Implements the Sandbox protocol (backend/sandbox/sandbox.py) by delegating
    to the task container with a fixed working directory.
    """

    def __init__(self, task: TaskSandbox, member: str, workdir: str):
        self._task = task
        self.member = member
        self.name = f"{task.project_id}-{member}"
        self.workdir = workdir

    def start(self) -> None:
        self._task.start()

    def exec(self, command: str, timeout: int = 60) -> ExecResult:
        return self._task.exec_bounded(command, workdir=self.workdir, timeout=timeout)

    def configure_output(self, limit: int) -> None:
        self._task.output_limit = max(1024, int(limit))

    def read_page(self, path: str, *, offset: int = 0, limit: int = 8192) -> dict:
        return self._task.read_page(path, workdir=self.workdir, offset=offset, limit=limit)

    # Async mirrors of the blocking surface; see TaskSandbox.aexec for why the
    # thread hop is mandatory inside a coroutine.
    async def aexec(self, command: str, timeout: int = 60) -> ExecResult:
        return await self._task.aexec_bounded(
            command, workdir=self.workdir, timeout=timeout
        )

    async def aread_page(
        self, path: str, *, offset: int = 0, limit: int = 8192
    ) -> dict:
        return await self._task.aread_page(
            path, workdir=self.workdir, offset=offset, limit=limit
        )

    async def aexec_detached(self, job_id: str, command: str) -> int:
        return await self._task.aexec_detached(job_id, command, self.workdir)

    async def ajob_state(self, job_id: str) -> dict:
        return await self._task.ajob_state(job_id)

    async def ajob_output(
        self, job_id: str, stream: str = "stdout", *, offset: int = 0,
        limit: int = 32_768,
    ) -> tuple[str, int]:
        return await self._task.ajob_output(
            job_id, stream, offset=offset, limit=limit
        )

    async def ajob_cancel(self, job_id: str) -> bool:
        return await self._task.ajob_cancel(job_id)


    def exec_detached(self, job_id: str, command: str) -> int:
        return self._task.exec_detached(job_id, command, workdir=self.workdir)

    def job_state(self, job_id: str) -> dict:
        return self._task.job_state(job_id)

    def job_output(
        self, job_id: str, stream: str = "stdout", *, offset: int = 0,
        limit: int = 32_768,
    ) -> tuple[str, int]:
        return self._task.job_output(job_id, stream, offset=offset, limit=limit)

    def job_cancel(self, job_id: str) -> bool:
        return self._task.job_cancel(job_id)

    def write_file(self, rel_path: str, content: str) -> None:
        self._task.write_file(self.workdir, rel_path, content)

    def read_file(self, rel_path: str) -> str | None:
        return self._task.read_file(self.workdir, rel_path)

    def stop(self) -> None:
        return None

    def visible_attachment_path(self, filename: str, original_path: str | None = None) -> str:
        safe_name = PurePosixPath(filename).name
        return str(PurePosixPath(ATTACHMENTS_DIR) / safe_name)

    def expose_webui(self, project_id: str, member: str, port: int) -> str:
        self._task.start()
        target_host = self._task.proxy_target_host()
        handle = webui_proxy_manager.register(project_id, member, target_host, port)
        return handle.url
