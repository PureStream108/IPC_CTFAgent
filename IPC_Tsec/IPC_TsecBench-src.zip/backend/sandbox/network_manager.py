from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path

from backend.sandbox.errors import (
    DockerConfigurationError,
    SandboxStartupError,
    classify_docker_cli_error,
    classify_docker_startup_error,
)

_recovery_logger = logging.getLogger(__name__)

@dataclass
class ChallengeEnv:
    project_id: str
    compose_file: str | None = None
    dockerfile: str | None = None
    network_name: str = ""
    started: bool = False
    endpoints: list[str] = field(default_factory=list)
    error: str | None = None
    startup_error: SandboxStartupError | None = field(default=None, repr=False)


class NetworkManager:
    def __init__(self, backend: str = "local"):
        self.backend = backend
        self._envs: dict[str, ChallengeEnv] = {}
        self._lock = threading.Lock()

    def detect(self, attachments_dir: str | Path) -> ChallengeEnv | None:
        """Look for a Dockerfile / docker-compose.* in the attachments."""
        d = Path(attachments_dir)
        if not d.exists():
            return None
        compose = None
        dockerfile = None
        for pat in ("docker-compose.yml", "docker-compose.yaml", "compose.yml"):
            candidate = d / pat
            if candidate.exists():
                compose = str(candidate)
                break
        df = d / "Dockerfile"
        if df.exists():
            dockerfile = str(df)
        if compose is None and dockerfile is None:
            return None
        return ChallengeEnv(project_id="", compose_file=compose, dockerfile=dockerfile)

    def start(self, project_id: str, attachments_dir: str | Path) -> ChallengeEnv | None:
        env = self.detect(attachments_dir)
        if env is None:
            return None
        env.project_id = project_id
        env.network_name = f"ipc-proj-{project_id}"
        if self.backend == "docker":
            env.started = self._docker_up(env)
        else:
            env.started = True
        with self._lock:
            self._envs[project_id] = env
        return env

    def _docker_up(self, env: ChallengeEnv) -> bool:
        import subprocess

        try:
            if env.compose_file:
                subprocess.run(
                    ["docker", "compose", "-p", env.network_name, "-f", env.compose_file, "up", "-d"],
                    check=True,
                    capture_output=True,
                )
            elif env.dockerfile:
                img = f"{env.network_name}-img"
                ctx = str(Path(env.dockerfile).parent)
                subprocess.run(["docker", "build", "-t", img, ctx], check=True, capture_output=True)
                subprocess.run(
                    ["docker", "run", "-d", "--name", env.network_name, img],
                    check=True,
                    capture_output=True,
                )
            return True
        except subprocess.CalledProcessError as exc:
            output = exc.stderr or exc.stdout or b""
            if isinstance(output, bytes):
                output = output.decode("utf-8", errors="replace")
            detail = str(output).strip()
            message = f"docker command failed with exit code {exc.returncode}"
            if detail:
                message += f": {detail[-4000:]}"
            env.startup_error = classify_docker_cli_error(
                message,
                "start challenge environment",
            )
            env.error = str(env.startup_error)
            return False
        except FileNotFoundError:
            env.startup_error = DockerConfigurationError(
                "Docker CLI is unavailable; install Docker and ensure `docker` is on PATH",
                operation="start challenge environment",
            )
            env.error = str(env.startup_error)
            return False
        except Exception as exc:
            _recovery_logger.debug('Error handled in _docker_up', exc_info=True)
            env.startup_error = classify_docker_startup_error(
                exc,
                "start challenge environment",
            )
            env.error = str(env.startup_error)
            return False

    def get(self, project_id: str) -> ChallengeEnv | None:
        with self._lock:
            return self._envs.get(project_id)

    def stop(self, project_id: str) -> None:
        with self._lock:
            env = self._envs.pop(project_id, None)
        if env is None or self.backend != "docker":
            return
        self._docker_down(env)

    def _docker_down(self, env: ChallengeEnv) -> None:
        import subprocess

        try:
            if env.compose_file:
                subprocess.run(
                    ["docker", "compose", "-p", env.network_name, "-f", env.compose_file, "down"],
                    check=False,
                    capture_output=True,
                )
            else:
                subprocess.run(["docker", "rm", "-f", env.network_name], check=False, capture_output=True)
        except Exception:
            _recovery_logger.debug('Error handled in _docker_down', exc_info=True)
