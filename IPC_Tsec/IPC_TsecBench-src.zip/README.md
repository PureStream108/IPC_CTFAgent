# IPC_TsecBench - hosted agent bundle

This directory is the build context for the **托管模式-Agent评测** (hosted agent)
evaluation at
`https://tsecbench.zc.tencent.com/benchmark/prepare/4?mode=hosted&evaluation_type=agent`.

The prepare page ends with: *"确保您的容器镜像在启动后，将会自行开始解题"*. This
bundle makes that true. One container starts, PostgreSQL and IPC come up, the
autopilot registers the benchmark task by itself, reads the challenge list,
pulls containers and hands them to the solving team. No operator, no browser,
no shell.

## 1. What the platform requires

Taken from the prepare page (`BenchmarkPrepareView`), in the order it states them:

| Requirement | Detail | Where it is implemented |
|---|---|---|
| No public internet | The sandbox can only reach the LLM gateway and the task's own containers | `hosted/bootstrap_config.py` rewrites every model base URL to `<host>.tsecbench.gw` over http |
| LLM gateway | Append `.tsecbench.gw` to the original host, change `https` to `http`, keep the path. Only Chat Completions / OpenAI Responses / Anthropic Messages are proxied | `via_gateway()` |
| Whitelisted model API | The original host must be in the platform whitelist (`api.deepseek.com`, `api.moonshot.cn`, `dashscope.aliyuncs.com`, ...) | default base URL is `api.deepseek.com` |
| Docker image upload | `.tar` / `.tar.gz` / `.tgz`, at most **3 GB**, produced with `docker save` | `Dockerfile.hosted` + section 3 |
| Resources | 8 vCPU, 16 GB RAM, 20 GB disk | `IPC_HOSTED_CPUS=8`, PostgreSQL is local, artifacts stay under `/app/data` |
| Platform-injected env | `BENCHMARK_TOKEN`, `BENCHMARK_BASE_URL` are supplied by the platform and must **not** be repeated in the page's env list | read by `hosted/autopilot.py` |
| Runtime env | Secrets and model settings arrive as page-configured environment variables | section 4 |
| Audit | Traffic and model conversations are recorded; the environment is destroyed afterwards | stdout is the audit trail: every platform call and every supervision tick |
| Local mode first | The agent must already speak the platform API | IPC's `backend/platform/tsecbench` adapter is that integration |

## 2. What happens when the container starts

`hosted/entrypoint.sh`:

1. `initdb` a disposable PostgreSQL cluster under `/var/lib/ipc-postgres` and start it on `127.0.0.1:5432` (no external database service exists in the sandbox).
2. `python -m hosted.bootstrap_config` renders `backend/config/config.yaml` from the environment and refuses to continue if IPC would not be able to solve `(missing key, bad api_format, ...)`.
3. `alembic upgrade head` creates the schema.
4. `uvicorn backend.server.app:app` serves IPC on `:8000`.
5. `python -m hosted.autopilot` takes over:

```
wait /health
  -> GET  /api/ops/workflows              (reuse an existing TSecBench workflow)
     POST /api/ops/workflows/tsecbench    (or create one from BENCHMARK_BASE_URL)
  -> POST /api/ops/workflows/{id}/confirm (authorize the platform origin)
  -> POST /api/workflows/{id}/preflight   (read the challenge list: 阅读)
  -> POST /api/workflows/{id}/start       (scheduler pulls containers: 拉题)
  -> GET  /api/runs/{id} every 30s        (supervise, resume when blocked)
```

Members run **inside this container** (`IPC_ALLOW_LOCAL_SANDBOX=1`,
`runtime.sandbox_backend: local`). The hosted sandbox is already single-use and
isolated, and no docker daemon exists inside it, so a nested container
sandbox would be both unavailable and pointless.

## 3. Build and upload

The build context is a mirror of the checkout, not a fork. Refresh it after any
backend change and gate the build on the drift check:

```bash
python scripts/sync_tsecbench_bundle.py D:/Desktop/Codex/IPC_CTFAgent/IPC_TsecBench
python scripts/sync_tsecbench_bundle.py D:/Desktop/Codex/IPC_CTFAgent/IPC_TsecBench --check
```

```bash
docker build -f Dockerfile.hosted -t ipc-tsecbench:latest .
docker run --rm ipc-tsecbench:latest sh -c "echo passthrough ok"

# exactly the command the prepare page documents; 3 GB applies to this file
docker save ipc-tsecbench:latest | gzip > agent.tar.gz
ls -lh agent.tar.gz        # 551 MB
```

The upload accepts `.tar`, `.tar.gz` and `.tgz` only (the picker also lists
`.xz`, but the page's own validator rejects it with "仅支持 .tar / .tar.gz /
.tgz"), and the file must stay under 3 GB.

Then on the prepare page: choose the Agent, drop `agent.tar.gz` into the upload
zone, fill in the environment variables from section 4, tick the agreement and
press 提交程序，进入运行队列.

The archive is whatever `docker save` emits. Docker 25 and newer write the OCI
layout (`blobs/sha256/...` + `index.json` + `manifest.json`), which older
engines cannot load. Current build facts: 551 MB, `linux/amd64`, one tag
`ipc-tsecbench:latest`, entrypoint `/app/hosted/entrypoint.sh`. If the
platform's loader rejects the OCI layout, re-export from an engine with the
classic image store (`docker save` then gives `layer.tar` + `repositories`).

Build arguments, all optional:

| Argument | Purpose |
|---|---|
| `APT_MIRROR` | rewrite `http://deb.debian.org/debian` to a mirror |
| `PIP_INDEX` | pip index URL |
| `INSTALL_SKILLS=0` | skip the skill package download |

## 4. Environment variables

Set these on the prepare page (they are injected into the container at run
time). **`BENCHMARK_TOKEN` and `BENCHMARK_BASE_URL` are supplied by the
platform** - adding them to this list is rejected by the page.

| Variable | Required | Default | Meaning |
|---|---|---|---|
| `IPC_LLM_API_KEY` | yes | - | model API key, reaches the gateway as the bearer secret |
| `IPC_LLM_BASE_URL` | no | `https://api.deepseek.com/anthropic` | original vendor URL; the gateway suffix is added automatically |
| `IPC_LLM_API_FORMAT` | no | `anthropic` | `anthropic` \| `openai` \| `deepseek` |
| `IPC_LLM_MODEL` | no | `deepseek-v4-flash` for a DeepSeek gateway | model id |
| `IPC_LLM_REASONING_EFFORT` | no | `max` | `low` \| `medium` \| `high` \| `xhigh` \| `max` |
| `IPC_LLM_GATEWAY` | no | `1` | set `0` only when the URL already points at the gateway |
| `IPC_DIAMOND_*` | no | inherits | same keys as above for Diamond alone |
| `IPC_HOSTED_DURATION_MINUTES` | no | `360` | local deadline guard for the 6 h window |
| `IPC_HOSTED_REMOTE_CONCURRENCY` | no | `3` | the platform's documented container cap |
| `IPC_HOSTED_MAX_TASKS` | no | `10` | concurrent challenge projects inside IPC |
| `IPC_HOSTED_PER_CHALLENGE_MINUTES` | no | `45` | park a stalled challenge after this long |
| `IPC_HOSTED_AUTOSTART` | no | `1` | `0` leaves the run to an operator |
| `IPC_HOSTED_POLL_SECONDS` | no | `30` | supervision interval |
| `IPC_HOSTED_HEARTBEAT_SECONDS` | no | `300` | how often the unchanged summary is repeated into the audit log |
| `IPC_HOSTED_ALLOW_PRIVATE` | no | auto | forces the workflow network policy. Auto-detected: an `http` or `*.tsecbench.gw` task origin opts in because that is the platform's own gateway alias |

The account's actual values are pre-filled in `env.hosted` at the bundle root:
two DeepSeek keys (Member seats vs Diamond + the IPC chat), the Anthropic-shaped
gateway URL, model `deepseek-flash` and reasoning effort `max`.

```bash
# what the page gets (BENCHMARK_* stay platform-injected)
cat env.hosted
```

```
IPC_LLM_API_FORMAT=anthropic
IPC_LLM_BASE_URL=http://api.deepseek.com.tsecbench.gw/anthropic
IPC_LLM_MODEL=deepseek-flash
IPC_LLM_REASONING_EFFORT=max
IPC_LLM_API_KEY=sk-ccd2...            # Member seats
IPC_DIAMOND_API_KEY=sk-7fc4...        # Diamond
IPC_OPS_API_KEY=sk-7fc4...            # IPC conversation agent (defaults to Diamond)
IPC_HOSTED_DURATION_MINUTES=360
IPC_HOSTED_REMOTE_CONCURRENCY=3
```

`env.hosted` is listed in `.dockerignore`: the keys travel as runtime
environment, never inside the image. The prepare page requires exactly that
("程序包内请将动态、敏感配置剔除，以环境变量形式读取"), and an image with a
baked-in key is also the first thing an audit would flag.

## 4.1 How the two platform-injected variables are handled

The page injects `BENCHMARK_TOKEN` and `BENCHMARK_BASE_URL` into the container
and forbids listing them yourself. The bundle consumes them in one place:

1. `hosted/autopilot.py` reads them from the environment and refuses to start
   (exit 2) when either is missing, instead of idling for six hours.
2. `BENCHMARK_BASE_URL` is reduced to its origin, because the workflow
   validator only accepts an origin and the adapter ignores the path anyway.
   A trailing slash or `/openapi/v1` therefore cannot fail the run.
   The platform hands out its **gateway alias** here, for example
   `http://tsecbench.zc.tencent.com.tsecbench.gw` - http, no public host. IPC's
   workflow validator rejects an http origin unless the workflow opts into
   private addresses, so the autopilot opts in automatically for that shape.
3. The token becomes the workflow secret `benchmark_token` (stored in
   PostgreSQL via the workflow API on create, re-sent on reuse). The adapter
   sends it as the `BENCHMARK_TOKEN` header; nothing else in the image reads
   it.
4. The token is then removed from every solver shell:
   `backend/sandbox/sandbox.py` filters `BENCHMARK_*` and the `IPC_*` model
   keys out of the child environment, so a Member cannot start or close
   containers behind the scheduler's back or spend the model quota directly.

Verified inside the built image:

```
[autopilot] BENCHMARK_BASE_URL reduced to its origin: http://host.docker.internal:8899
[autopilot] preflight: 4 challenges (4 with containers)
parent BENCHMARK_TOKEN set: True
child BENCHMARK_TOKEN: False
child IPC_LLM_API_KEY: False
```

## 5. Rehearsal before uploading

`hosted/rehearse_platform.py` is a fixture that speaks the same OpenAPI. It
proves the image bootstraps, lists challenges and pulls containers without
spending a graded run:

```bash
python hosted/rehearse_platform.py --port 8899 --challenges 6

docker run --rm -p 8000:8000 \
  -e BENCHMARK_BASE_URL=http://host.docker.internal:8899 \
  -e BENCHMARK_TOKEN=rehearsal-token \
  -e IPC_HOSTED_ALLOW_PRIVATE=1 \
  -e IPC_LLM_API_KEY=sk-placeholder \
  -e IPC_LLM_MODEL=deepseek-v4-flash \
  ipc-tsecbench:latest
```

Expected log, in order:

```
[entrypoint] starting PostgreSQL on 127.0.0.1:5432
[config] ready with members ['amber', ...]
[autopilot] IPC server is up at http://127.0.0.1:8000
[autopilot] created workflow wf_...
[autopilot] workflow confirmed
[autopilot] preflight: 6 challenges (6 with containers), limits {...}
[autopilot] run started run_... status=running challenges=6
[autopilot] status=running solved=0/6 containers=3/3 solving=...
```

`containers=3/3` is the scheduler holding the platform's cap, and the fixture
prints `[fixture] start ...` in step with it.

## 6. Troubleshooting

| Symptom | Cause |
|---|---|
| `[config] STARTUP ERROR: Diamond requires api_key and base_url` | `IPC_LLM_API_KEY` was not set on the page |
| `preflight failed: HTTP 404: task_not_found` | `BENCHMARK_TOKEN` is stale; the task ended or was stopped |
| `workflow hostname resolves to a non-public address` | the platform URL is private, which only the rehearsal fixture needs (`IPC_HOSTED_ALLOW_PRIVATE=1`) |
| `preflight: 0 challenges` | the task has no challenge set, or the token scopes a different task |
| Model calls return 403/404 through the gateway | the original host is not on the platform's model API whitelist |
| `run reached terminal state failed` | every Member failed; read `/app/data/artifacts/logs/` inside the container |

## 7. Layout

```
Dockerfile.hosted          image: python 3.12 + PostgreSQL + IPC + autopilot
hosted/entrypoint.sh       PostgreSQL -> config -> migrations -> IPC -> autopilot
hosted/bootstrap_config.py environment -> backend/config/config.yaml (+ gateway rewrite)
hosted/autopilot.py        workflow -> confirm -> preflight -> start -> supervise
hosted/rehearse_platform.py  fixture platform for a dry run
backend/                   IPC source (the solving team and the TSecBench adapter)
frontend/                  the operator UI, reachable on :8000 inside the sandbox
```
